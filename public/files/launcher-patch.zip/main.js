/* nvPROTECTED */
const { ipcRenderer } = require('electron');
const fs = require('fs');
const path = require('path');
let I18N = {};
document.addEventListener('DOMContentLoaded', () => {
// Убираем legacy-флаг слабого режима лаунчера: оптимизация касается только игры
try { localStorage.removeItem('nebula_low_power'); } catch (e) { }
try { document.body.classList.remove('low-power'); } catch (e) { }
const defaultAvatarPath = "E:/\u0432\u0438\u0437\u0443\u0430\u043b 1.21.4/Nebula Visuals 1.21.4/icon.png";
const userAvatar = document.getElementById('userAvatar');
if (userAvatar && fs.existsSync(defaultAvatarPath)) {
const formattedPath = defaultAvatarPath.replace(/\\/g, '/');
userAvatar.style.backgroundImage = `url('file://${formattedPath}')`;
}
const AUTH_SESSION_KEY = 'nebula_session';
const authOverlay = document.getElementById('authOverlay');
const authForm = document.getElementById('authForm');
const authTitle = document.getElementById('authTitle');
const authSubtitle = document.getElementById('authSubtitle');
const authTabLogin = document.getElementById('authTabLogin');
const authTabRegister = document.getElementById('authTabRegister');
const authUsername = document.getElementById('authUsername');
const authEmail = document.getElementById('authEmail');
const authPassword = document.getElementById('authPassword');
const authConfirm = document.getElementById('authConfirm');
const authError = document.getElementById('authError');
const authSubmit = document.getElementById('authSubmit');
const authHint = document.getElementById('authHint');
const authGroupUsername = document.getElementById('authGroupUsername');
const authGroupPassword = document.getElementById('authGroupPassword');
const authGroupEmail = document.getElementById('authGroupEmail');
const authGroupConfirm = document.getElementById('authGroupConfirm');
const authPwdToggle = document.getElementById('authPwdToggle');
const authCode = document.getElementById('authCode');
let authMode = 'login';
const SESSION_FILE = (function () { try { const base = process.env.APPDATA || path.join(process.env.USERPROFILE || '', 'AppData', 'Roaming'); return path.join(base, 'Celestial-Skid', 'launcher-session.json'); } catch (e) { return ''; } })();
function readSessionFile() { try { if (SESSION_FILE && fs.existsSync(SESSION_FILE)) { const f = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8')); if (f && f.username) return f; } } catch (e) { } return null; }
function writeSessionFile(user) { try { if (!SESSION_FILE) return; const dir = path.dirname(SESSION_FILE); if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(SESSION_FILE, JSON.stringify(user), 'utf8'); } catch (e) { } }
function getSession() { try { const ls = JSON.parse(localStorage.getItem(AUTH_SESSION_KEY)); if (ls && ls.username) return ls; } catch (e) { } return readSessionFile(); }
function setSession(user) { try { localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(user)); } catch (e) { } writeSessionFile(user); }
function clearSession() { try { localStorage.removeItem(AUTH_SESSION_KEY); } catch (e) { } try { if (SESSION_FILE && fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE); } catch (e) { } }

function showAuthError(msg) {
if (!authError) return;
authError.textContent = msg || '';
[authGroupUsername, authGroupPassword].forEach(g => {
if (!g) return;
g.classList.remove('error');
if (msg) { void g.offsetWidth; g.classList.add('error'); }
});
}
function setAuthMode(mode) {
authMode = mode;
const isLogin = mode === 'login';
if (authTabLogin) authTabLogin.classList.toggle('active', isLogin);
if (authTabRegister) authTabRegister.classList.toggle('active', !isLogin);
if (authTitle) authTitle.textContent = isLogin ? '\u0412\u0445\u043e\u0434' : '\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f';
if (authSubtitle) authSubtitle.textContent = isLogin
? '\u0412\u043e\u0439\u0434\u0438\u0442\u0435 \u0442\u0435\u043c \u0436\u0435 \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u043e\u043c, \u0447\u0442\u043e \u0438 \u043d\u0430 \u0441\u0430\u0439\u0442\u0435'
: '\u0421\u043e\u0437\u0434\u0430\u0439\u0442\u0435 \u0430\u043a\u043a\u0430\u0443\u043d\u0442, \u043a\u0430\u043a \u043d\u0430 \u0441\u0430\u0439\u0442\u0435 Nebula Visuals';
if (authGroupEmail) authGroupEmail.style.display = isLogin ? 'none' : '';
if (authGroupConfirm) authGroupConfirm.style.display = isLogin ? 'none' : '';
if (authSubmit) authSubmit.textContent = isLogin ? '\u0412\u041e\u0419\u0422\u0418' : '\u0417\u0410\u0420\u0415\u0413\u0418\u0421\u0422\u0420\u0418\u0420\u041e\u0412\u0410\u0422\u042c\u0421\u042f';
if (authHint) authHint.textContent = isLogin
? '\u041d\u0435\u0442 \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430? \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \xab\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f\xbb'
: '\u0423\u0436\u0435 \u0435\u0441\u0442\u044c \u0430\u043a\u043a\u0430\u0443\u043d\u0442? \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \xab\u0412\u0445\u043e\u0434\xbb';
showAuthError('');
}
if (authTabLogin) authTabLogin.addEventListener('click', () => setAuthMode('login'));
if (authTabRegister) authTabRegister.addEventListener('click', () => setAuthMode('register'));
if (authPwdToggle && authPassword) {
authPwdToggle.addEventListener('click', () => {
const isPwd = authPassword.type === 'password';
authPassword.type = isPwd ? 'text' : 'password';
authPassword.focus();
});
}
function hideAuthOverlay() {
if (authOverlay) authOverlay.classList.add('hidden');
}
function showAuthOverlay() {
if (authOverlay) authOverlay.classList.remove('hidden');
setAuthMode('login');
autofillSaved();
}
function autofillSaved() {
var saved = null;
try { saved = JSON.parse(localStorage.getItem('nebula_saved')) || null; } catch (e) { }
if (!saved) return;
if (authUsername && !authUsername.value) authUsername.value = saved.username || '';
if (authPassword && !authPassword.value) authPassword.value = saved.password || '';
if (authCode && !authCode.value && saved.code) authCode.value = saved.code;
try { if (authUsername) authUsername.focus(); } catch (e) { }
}
function saveAutofill(username, password, code) {
try { localStorage.setItem('nebula_saved', JSON.stringify({ username: username || '', password: password || '', code: code || '' })); } catch (e) { }
}
function translateGroup(group) {
if (!group) return t('role_player', '\u0418\u0433\u0440\u043e\u043a');
const map = { admin: 'role_admin', coder: 'role_coder', tester: 'role_tester' };
if (group.indexOf('†') === -1) {
const key = map[group.trim()];
return key ? t(key, group) : group;
}
return group.split('†').map(function (part) {
const code = part.trim();
const key = map[code];
return key ? t(key, code) : code;
}).join(' \u2020 ');
}
function applyGroupToEl(el, group) {
if (!el) return;
el.innerText = translateGroup(group);
el.classList.remove('group-admin', 'group-coder', 'group-tester', 'group-player');
const g = String(group || '');
if (g.indexOf('admin') !== -1) el.classList.add('group-admin');
else if (g.indexOf('coder') !== -1) el.classList.add('group-coder');
else if (g.indexOf('tester') !== -1) el.classList.add('group-tester');
else el.classList.add('group-player');
}
function applyUser(user) {
if (!user) return;
localStorage.setItem('nebula_username', user.username || '');
const loginEl = document.getElementById('profile-login');
const mcNickEl = document.getElementById('profile-mc-nick');
const groupEl = document.getElementById('profile-group');
const mcNickInput = document.getElementById('mc-nick-input');
const codeInput = document.getElementById('profile-code-input');
if (loginEl) loginEl.innerText = user.username || '';
if (mcNickEl) mcNickEl.innerText = user.username || '';
if (groupEl) applyGroupToEl(groupEl, user.group);
if (mcNickInput) mcNickInput.value = user.username || '';
if (codeInput) codeInput.value = user.code || '';
}
if (authForm) {
authForm.addEventListener('submit', async (e) => {
e.preventDefault();
showAuthError('');
const username = (authUsername && authUsername.value.trim()) || '';
const password = (authPassword && authPassword.value) || '';
if (!username || !password) { showAuthError(t('err_fill_all', '\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0432\u0441\u0435 \u043f\u043e\u043b\u044f')); return; }
if (username.length < 3 || username.length > 16) { showAuthError(t('err_nick_len', '\u041d\u0438\u043a: 3\u201316 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432')); return; }
if (!/^[A-Za-z0-9_]+$/.test(username)) { showAuthError(t('err_nick_chars', '\u041d\u0438\u043a: \u0442\u043e\u043b\u044c\u043a\u043e \u043b\u0430\u0442\u0438\u043d\u0438\u0446\u0430, \u0446\u0438\u0444\u0440\u044b \u0438 _')); return; }
if (authMode === 'login') {
if (authSubmit) { authSubmit.disabled = true; authSubmit.textContent = '\u0412\u0425\u041e\u0414...'; }
const code = (authCode && authCode.value.trim()) || '';
const res = await ipcRenderer.invoke('auth:login', { username, password, code: code });
if (authSubmit) { authSubmit.disabled = false; authSubmit.textContent = '\u0412\u041e\u0419\u0422\u0418'; }
if (!res || !res.ok) {
const prevSession = getSession();
if (res && res.network && prevSession && prevSession.username === username && prevSession.password === password) {
saveAutofill(username, password, code);
applyUser(prevSession);
hideAuthOverlay();
startFullVerify();
return;
}
showAuthError((res && res.error) || '\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043d\u0438\u043a \u0438\u043b\u0438 \u043f\u0430\u0440\u043e\u043b\u044c');
return;
}
saveAutofill(username, password, code);
setSession(Object.assign({}, res.user, { password: password, code: code }));
applyUser(res.user);
if (authCode) authCode.value = '';
hideAuthOverlay();
startFullVerify();
} else {
const email = (authEmail && authEmail.value.trim().toLowerCase()) || '';
const confirm = (authConfirm && authConfirm.value) || '';
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showAuthError(t('err_email', '\u041d\u0435\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u044b\u0439 email')); return; }
if (password.length < 6) { showAuthError(t('err_pass_len', '\u041f\u0430\u0440\u043e\u043b\u044c \u043c\u0438\u043d\u0438\u043c\u0443\u043c 6 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432')); return; }
if (password !== confirm) { showAuthError(t('err_pass_mismatch', '\u041f\u0430\u0440\u043e\u043b\u0438 \u043d\u0435 \u0441\u043e\u0432\u043f\u0430\u0434\u0430\u044e\u0442')); return; }
if (authSubmit) { authSubmit.disabled = true; authSubmit.textContent = '\u0420\u0415\u0413\u0418\u0421\u0422\u0420\u0410\u0426\u0418\u042f...'; }
const res = await ipcRenderer.invoke('auth:register', { username, email, password });
if (authSubmit) { authSubmit.disabled = false; authSubmit.textContent = '\u0417\u0410\u0420\u0415\u0413\u0418\u0421\u0422\u0420\u0418\u0420\u041e\u0412\u0410\u0422\u042c\u0421\u042f'; }
if (!res || !res.ok) { showAuthError((res && res.error) || '\u041e\u0448\u0438\u0431\u043a\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438'); return; }
saveAutofill(username, password, '');
setSession(Object.assign({}, res.user, { password: password }));
applyUser(res.user);
hideAuthOverlay();
startFullVerify();
}
});
}
const verifyOverlay = document.getElementById('verifyOverlay');
const verifyText = document.getElementById('verifyText');
const verifySub = document.getElementById('verifySub');
let verifyState = null;
function setVerifyState(text, sub, kind) {
verifyState = { text: text || '', sub: sub || '', kind: kind || '' };
if (verifyText) {
verifyText.textContent = text || '';
verifyText.className = 'verify-text' + (kind ? ' is-' + kind : '');
}
if (verifySub) verifySub.textContent = sub || '';
}
function showVerify(text, sub, kind) {
if (!verifyOverlay) return;
verifyOverlay.classList.remove('hidden');
setVerifyState(text, sub, kind);
}
function hideVerify() {
if (verifyOverlay) verifyOverlay.classList.add('hidden');
}
async function verifySessionOnStart() {
const session = getSession();
if (!session || !session.username || !session.password) {
hideVerify();
showAuthOverlay();
setAuthMode('login');
return;
}
showVerify(t('verify_checking', '\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u0435\u043c \u0434\u0430\u043d\u043d\u044b\u0435 \u0441 \u0441\u0430\u0439\u0442\u043e\u043c...'), t('verify_sub', '\u041f\u043e\u0434\u043e\u0436\u0434\u0438\u0442\u0435, \u0438\u0434\u0451\u0442 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430'), 'ok');
const res = await ipcRenderer.invoke('auth:verify', {
username: session.username,
password: session.password,
code: session.code || ''
});
if (res && res.ok) {
const user = Object.assign({}, session, res.user, { password: session.password });
setSession(user);
saveAutofill(session.username, session.password, session.code || '');
applyUser(user);
setVerifyState(t('verify_ok', '\u0423\u0441\u043f\u0435\u0448\u043d\u043e'), t('verify_ok_sub', '\u0412\u0445\u043e\u0434 \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d, \u0432\u044b\u0431\u0438\u0440\u0430\u0439\u0442\u0435 \u0441\u0431\u043e\u0440\u043a\u0443'), 'ok');
await new Promise((r) => setTimeout(r, 900));
hideVerify();
hideAuthOverlay();
startFullVerify();
return;
}
if (res && res.network) {
applyUser(session);
hideVerify();
hideAuthOverlay();
startFullVerify();
return;
}
hideVerify();
clearSession();
localStorage.removeItem('nebula_username');
showAuthOverlay();
setAuthMode('login');
showAuthError((res && res.error) || t('msg_session_fail', '\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u0441\u0435\u0441\u0441\u0438\u044e, \u0432\u043e\u0439\u0434\u0438\u0442\u0435 \u0437\u0430\u043d\u043e\u0432\u043e'));
}
// ===== Проверка всех файлов после входа (экран в стиле WILD Client) =====
const updateNotice = document.getElementById('updateNotice');
const updateOverlay = document.getElementById('updateOverlay');
const vfPercent = document.getElementById('vfPercent');
const vfSub = document.getElementById('vfSub');
const vfError = document.getElementById('vfError');
const vfErrorText = document.getElementById('vfErrorText');
const vfRetry = document.getElementById('vfRetry');
const vfSkip = document.getElementById('vfSkip');
const vfMinimize = document.getElementById('vfMinimize');
const vfClose = document.getElementById('vfClose');
function showUpdateNotice() { if (updateNotice) updateNotice.hidden = false; }
function hideUpdateNotice() { if (updateNotice) updateNotice.hidden = true; }
function setVfPercent(p) { if (vfPercent) vfPercent.textContent = String(Math.max(0, Math.min(100, Math.round(p) || 0))); }
function setVfSub(t) { if (vfSub) vfSub.textContent = t || ''; }
function showUpdateOverlay() {
  if (!updateOverlay) return;
  updateOverlay.hidden = false;
  updateOverlay.setAttribute('aria-busy', 'true');
  setVfPercent(0);
  setVfSub('Подготовка...');
  if (vfError) vfError.hidden = true;
}
function hideUpdateOverlay() {
  if (!updateOverlay) return;
  updateOverlay.hidden = true;
  updateOverlay.setAttribute('aria-busy', 'false');
}
function showMainScreen() {
  const mainScreen = document.getElementById('screen-main');
  if (mainScreen) { mainScreen.style.display = 'block'; mainScreen.classList.add('active'); }
  try { const a = document.getElementById('authOverlay'); a && a.classList.add('hidden'); } catch (e) { }
  try { const v = document.getElementById('verifyOverlay'); v && v.classList.add('hidden'); } catch (e) { }
  hideUpdateOverlay();
}
function requestModUpdateCheck() { try { ipcRenderer.send('mods:check-updates'); } catch (e) { /* noop */ } }
function startFullVerify() {
  try { const v = document.getElementById('verifyOverlay'); v && v.classList.add('hidden'); } catch (e) { }
  showUpdateOverlay();
  requestModUpdateCheck();
}
if (vfRetry) vfRetry.addEventListener('click', () => { startFullVerify(); });
if (vfSkip) vfSkip.addEventListener('click', () => { hideUpdateNotice(); showMainScreen(); });
if (vfMinimize) vfMinimize.addEventListener('click', () => { try { ipcRenderer.send('window-minimize'); } catch (e) { } });
if (vfClose) vfClose.addEventListener('click', () => { try { ipcRenderer.send('window-close'); } catch (e) { } });
ipcRenderer.on('mods:update-found', () => { showUpdateNotice(); });
ipcRenderer.on('mods:update-none', () => { hideUpdateNotice(); });
ipcRenderer.on('verify:progress', (event, d) => {
  if (!d) return;
  setVfPercent(d.percent);
  if (d.sub) setVfSub(d.sub);
});
ipcRenderer.on('verify:done', () => {
  // локальная проверка пройдена — входим в меню; «Новое обновление!» остаётся,
  // пока клиент не будет обновлён (пропадёт сама после обновления)
  showMainScreen();
  requestAppUpdateCheck();
});
// ===== Проверка новой версии самого лаунчера (нажатие — обновление с анимацией) =====
const appUpdateOverlay = document.getElementById('appUpdateOverlay');
const appUpdatePercent = document.getElementById('appUpdatePercent');
const appUpdateSub = document.getElementById('appUpdateSub');
const appUpdateMinimize = document.getElementById('appUpdateMinimize');
const appUpdateClose = document.getElementById('appUpdateClose');
let appUpdateMode = false;
let appUpdateTimers = null;
let updateDlStart = 0;
let updateDlLast = null;
let updateSpeed = 0; // байт/сек, скользящая средняя
function fmtEta(sec) {
const s = Math.max(0, Math.round(sec));
if (s < 60) return s + ' сек';
const m = Math.floor(s / 60), r = s % 60;
if (m < 60) return m + ' мин' + (r ? ' ' + r + ' сек' : '');
const h = Math.floor(m / 60);
return h + ' ч ' + (m % 60) + ' мин';
}
function setAppUpdatePercent(p) { if (appUpdatePercent) appUpdatePercent.textContent = String(Math.max(0, Math.min(100, Math.round(p || 0)))); }
function setAppUpdateSub(t) { if (appUpdateSub) appUpdateSub.textContent = t || ''; }
function showAppUpdateOverlay() { if (appUpdateOverlay) { appUpdateOverlay.hidden = false; appUpdateOverlay.setAttribute('aria-busy', 'true'); } }
function hideAppUpdateOverlay() { if (appUpdateOverlay) { appUpdateOverlay.hidden = true; appUpdateOverlay.setAttribute('aria-busy', 'false'); } }
function setUpdateNoticeText(t) {
if (!updateNotice) return;
const span = updateNotice.querySelector('span:last-child');
if (span) span.textContent = t;
}
function requestAppUpdateCheck() {
try {
ipcRenderer.invoke('app:check-launcher-update').then((res) => {
if (res && res.ok && res.update && res.to) {
appUpdateMode = true;
if (updateNotice) {
updateNotice.hidden = false;
setUpdateNoticeText('Доступно обновление лаунчера ' + res.to + ' — нажми для установки');
}
}
}).catch(() => { });
} catch (e) { }
}
function startVirtualLoading(startedAt, minMs) {
const tick = () => {
const elapsed = Date.now() - startedAt;
const pct = Math.min(95, Math.floor((elapsed / minMs) * 95));
const remaining = Math.max(0, Math.ceil((minMs - elapsed) / 1000));
setAppUpdatePercent(pct);
if (appUpdateSub) {
appUpdateSub.textContent = 'Подключаюсь к серверу обновлений…';
}
if (elapsed < minMs) {
appUpdateTimers = setTimeout(tick, 200);
}
};
appUpdateTimers = setTimeout(tick, 100);
}
function finishVirtualLoading() {
if (appUpdateTimers) { clearTimeout(appUpdateTimers); appUpdateTimers = null; }
setAppUpdatePercent(100);
}
if (updateNotice) {
updateNotice.addEventListener('click', () => {
if (!appUpdateMode) return;
showAppUpdateOverlay();
setAppUpdatePercent(0);
setAppUpdateSub('Подготовка…');
updateDlStart = 0;
updateDlLast = null;
updateSpeed = 0;
const startedAt = Date.now();
const MIN_MS = 10000;
startVirtualLoading(startedAt, MIN_MS);
ipcRenderer.invoke('app:apply-launcher-update').then((res) => {
finishVirtualLoading();
if (res && res.ok && res.update) {
setAppUpdatePercent(100);
setAppUpdateSub('Готово — перезапускаю один момент…');
} else if (res && res.error) {
setAppUpdateSub('Ошибка обновления: ' + res.error);
setTimeout(hideAppUpdateOverlay, 4000);
}
}).catch(() => {
finishVirtualLoading();
setAppUpdateSub('Ошибка обновления');
setTimeout(hideAppUpdateOverlay, 4000);
});
});
}
ipcRenderer.on('update:progress', (event, d) => {
if (!d || !appUpdateOverlay || appUpdateOverlay.hidden) return;
if (appUpdateTimers) { clearTimeout(appUpdateTimers); appUpdateTimers = null; }
const pct = Math.max(0, Math.min(100, Math.round(d.percent || 0)));
setAppUpdatePercent(pct);
const mb = (n) => (Number(n) / 1048576).toFixed(1);
const now = Date.now();
if (!updateDlStart) updateDlStart = now;
if (d.received != null) {
if (updateDlLast) {
const dt = (now - updateDlLast.t) / 1000;
const db = Number(d.received) - updateDlLast.r;
if (dt > 0 && db >= 0) {
const inst = db / dt;
updateSpeed = updateSpeed > 0 ? updateSpeed * 0.7 + inst * 0.3 : inst;
}
}
updateDlLast = { t: now, r: Number(d.received) };
}
if (d.total > 0) {
let sub = 'Скачиваю обновление… ' + mb(d.received) + ' / ' + mb(d.total) + ' МБ';
const remaining = d.total - d.received;
if (remaining > 0 && updateSpeed > 20000) {
sub += ' · осталось ≈ ' + fmtEta(remaining / updateSpeed);
} else if (remaining > 0) {
sub += ' · считаю скорость…';
}
setAppUpdateSub(sub);
} else if (pct >= 100) {
setAppUpdateSub('Устанавливаю…');
}
});
if (appUpdateMinimize) appUpdateMinimize.addEventListener('click', () => { try { ipcRenderer.send('window-minimize'); } catch (e) { } });
if (appUpdateClose) appUpdateClose.addEventListener('click', () => { try { ipcRenderer.send('window-close'); } catch (e) { } });
ipcRenderer.on('verify:failed', (event, d) => {
  hideUpdateNotice();
  setVfSub('Проверка прервана');
  if (vfError && vfErrorText) {
    vfErrorText.textContent = (d && d.message)
      ? ('Не удалось проверить файлы: ' + d.message)
      : 'Не удалось проверить файлы. Проверьте интернет и попробуйте снова.';
    vfError.hidden = false;
  }
});
verifySessionOnStart();

// Версия в шапке и на экране проверки
try {
ipcRenderer.invoke('app:get-version').then((v) => {
const ver = String(v || '');
const a = document.getElementById('appVersion');
const b = document.getElementById('vfAppVersion');
if (a) a.textContent = ver;
if (b) b.textContent = ver;
}).catch(() => { });
} catch (e) { }
ipcRenderer.on('session:ready', (event, user) => {
try { setSession(Object.assign({}, user, { password: user.password || '' })); } catch (e) { }
applyUser(user);
try { authOverlay && authOverlay.classList.add('hidden'); } catch (e) { }
try { verifyOverlay && verifyOverlay.classList.add('hidden'); } catch (e) { }
startFullVerify();
});
let currentLanguage = localStorage.getItem('launcher_lang') || 'ru';
const langSelectorBtn = document.getElementById('langSelectorBtn');
const langDropdownMenu = document.getElementById('langDropdownMenu');
const currentLangText = document.getElementById('currentLangText');
const currentLangFlag = document.getElementById('currentLangFlag');
const langOptions = document.querySelectorAll('.lang-option');
function t(key, fallback) {
if (I18N && I18N[key]) return I18N[key];
return fallback != null ? fallback : key;
}
function tf(key, fallback, args) {
let str = t(key, fallback);
if (!args) return str;
for (let i = 0; i < args.length; i++) {
str = str.split('{' + i + '}').join(String(args[i]));
}
return str;
}
function applyTranslations(dict) {
I18N = dict || {};
window.__I18N = I18N;
document.querySelectorAll('[data-i18n]').forEach(element => {
const key = element.getAttribute('data-i18n');
if (!key || !I18N[key]) return;
if (element.querySelector('svg')) {
const svgHtml = element.querySelector('svg').outerHTML;
element.innerHTML = svgHtml + ' ' + I18N[key];
return;
}
if (element.children.length) {
for (let i = 0; i < element.childNodes.length; i++) {
const node = element.childNodes[i];
if (node.nodeType === 3 && node.textContent.trim()) {
node.textContent = I18N[key];
return;
}
}
return;
}
element.textContent = I18N[key];
});
document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
const key = element.getAttribute('data-i18n-placeholder');
if (key && I18N[key]) element.setAttribute('placeholder', I18N[key]);
});
document.querySelectorAll('[data-i18n-title]').forEach(element => {
const key = element.getAttribute('data-i18n-title');
if (key && I18N[key]) element.setAttribute('title', I18N[key]);
});
document.querySelectorAll('[data-i18n-aria]').forEach(element => {
const key = element.getAttribute('data-i18n-aria');
if (key && I18N[key]) element.setAttribute('aria-label', I18N[key]);
});
if (verifyState) {
const vt = document.getElementById('verifyText');
const vs = document.getElementById('verifySub');
if (vt) vt.textContent = verifyState.text;
if (vs) vs.textContent = verifyState.sub;
}
}
async function changeLanguage(lang) {
try {
const response = await fetch('./locales/' + lang + '.json');
if (!response.ok) throw new Error('Localization load error: ' + lang);
const dict = await response.json();
applyTranslations(dict);
localStorage.setItem('launcher_lang', lang);
currentLanguage = lang;
const langName = document.getElementById('currentLangText');
if (langName) langName.textContent = (lang === 'ru') ? t('lang_ru', '\u0420\u0443\u0441\u0441\u043a\u0438\u0439') : t('lang_en', 'English');
const langFlag = document.getElementById('currentLangFlag');
if (langFlag) langFlag.src = (lang === 'ru') ? 'https://flagcdn.com/w20/ru.png' : 'https://flagcdn.com/w20/us.png';
if (typeof renderMods === 'function' && typeof modsRendered !== 'undefined' && modsRendered && modsRendered.length) {
renderMods(modsRendered, 0);
}
if (typeof refreshClientText === 'function') refreshClientText();
if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
setTimeout(function () {
var cards = document.querySelectorAll('.version-row');
for (var i = 0; i < cards.length; i++) cards[i].style.animation = 'none';
}, 1200);
if (typeof startModsPreload === 'function') { try { startModsPreload(); } catch (e) { } }
} catch (err) {
console.error('Localization Error:', err);
}
}
changeLanguage(currentLanguage);
if (langSelectorBtn && langDropdownMenu) {
langSelectorBtn.addEventListener('click', (e) => {
e.stopPropagation();
const isHidden = langDropdownMenu.style.display === 'none' || langDropdownMenu.style.display === '';
langDropdownMenu.style.display = isHidden ? 'block' : 'none';
});
document.addEventListener('click', () => {
if (langDropdownMenu) langDropdownMenu.style.display = 'none';
});
}
langOptions.forEach(option => {
option.addEventListener('click', (e) => {
e.stopPropagation();
const selectedLang = option.getAttribute('data-lang');
if (selectedLang !== currentLanguage) changeLanguage(selectedLang);
if (langDropdownMenu) langDropdownMenu.style.display = 'none';
});
});
const navItems = document.querySelectorAll('.nav-item');
const screens = document.querySelectorAll('.screen');
const screenMain = document.getElementById('screen-main');
const clientCards = document.querySelectorAll('.version-row, .client-card');
const clientDetailScreen = document.getElementById('clientDetailScreen');
const backToCardsBtn = document.getElementById('backToCardsBtn');
const detailTitle = document.getElementById('detailTitle');
const detailSubtitle = document.getElementById('detailSubtitle');
const detailBanner = document.getElementById('detailBanner');
const detailDescription = document.getElementById('detailDescription');
const launchBtn = document.getElementById('launch-btn');
const launchBtnText = document.getElementById('launch-btn-text');
const CLIENTS = {
'1.21.4': {
subtitleKey: 'client_subtitle_client',
bg: 'bg-1214-card.png',
bgBanner: 'bg-1214-banner.png',
descKey: 'client_desc_1214',
btnKey: 'btn_launch',
desc: '\u041c\u044b \u0441\u043e\u0437\u0434\u0430\u043b\u0438 \u0434\u043b\u044f \u0432\u0430\u0441 \u043b\u0443\u0447\u0448\u0438\u0439 \u043a\u043b\u0438\u0435\u043d\u0442, \u043a\u043e\u0442\u043e\u0440\u044b\u0439 \u0434\u0430\u0441\u0442 \u0432\u0430\u043c \u043e\u0433\u0440\u043e\u043c\u043d\u043e\u0435 \u043f\u0440\u0435\u0438\u043c\u0443\u0449\u0435\u0441\u0442\u0432\u043e \u0432 \u0438\u0433\u0440\u0435 \u043d\u0430 FunTime. \u0412 \u044d\u0442\u043e\u043c \u043a\u043b\u0438\u0435\u043d\u0442\u0435 \u043e\u0433\u0440\u043e\u043c\u043d\u044b\u0439 \u0444\u0443\u043d\u043a\u0446\u0438\u043e\u043d\u0430\u043b, \u043a\u043e\u0442\u043e\u0440\u044b\u0439 \u0438\u0434\u0435\u0430\u043b\u044c\u043d\u043e \u043f\u043e\u0434\u043e\u0439\u0434\u0451\u0442 \u043f\u043e\u0434 \u044d\u0442\u043e\u0442 \u0441\u0435\u0440\u0432\u0435\u0440. \u041c\u044b \u043f\u043e\u0441\u0442\u043e\u044f\u043d\u043d\u043e \u0432\u044b\u043f\u0443\u0441\u043a\u0430\u0435\u043c \u0441\u0432\u0435\u0436\u0438\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f, \u0447\u0442\u043e\u0431\u044b \u0432\u0430\u0448 \u0438\u0433\u0440\u043e\u0432\u043e\u0439 \u043e\u043f\u044b\u0442 \u0441\u0442\u0430\u043b \u0435\u0449\u0451 \u043b\u0443\u0447\u0448\u0435.',
btn: '\u0417\u0410\u041f\u0423\u0421\u0422\u0418\u0422\u042c',
disabled: false
},
'1.21.11': {
subtitleKey: 'client_subtitle_beta',
bg: 'bg-1211-card.png',
bgBanner: 'bg-1211-banner.png',
descKey: 'client_desc_1211',
btnKey: 'client_beta_btn',
desc: '\u042d\u043a\u0441\u043f\u0435\u0440\u0438\u043c\u0435\u043d\u0442\u0430\u043b\u044c\u043d\u0430\u044f \u0441\u0431\u043e\u0440\u043a\u0430 Nebula Visuals \u0434\u043b\u044f Minecraft 1.21.11. \u0421\u0435\u0439\u0447\u0430\u0441 \u043e\u043d\u0430 \u043f\u0440\u043e\u0445\u043e\u0434\u0438\u0442 \u0442\u0435\u0441\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435 \u2014 \u0437\u0430\u043f\u0443\u0441\u043a \u043f\u043e\u043a\u0430 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d. \u0421\u043b\u0435\u0434\u0438\u0442\u0435 \u0437\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f\u043c\u0438 \u0432 Telegram \u043a\u0430\u043d\u0430\u043b\u0435.',
btn: '\u0422\u0415\u0421\u0422\u0418\u0420\u0423\u0415\u0422\u0421\u042f',
disabled: true
}
};
let selectedVersion = '1.21.4';
function refreshClientText() {
const cfg = CLIENTS[selectedVersion] || CLIENTS['1.21.4'];
if (detailSubtitle) detailSubtitle.textContent = t(cfg.subtitleKey, cfg.subtitle || '');
if (detailDescription) detailDescription.textContent = t(cfg.descKey, cfg.desc || '');
if (launchBtnText && !launchBtn.disabled) launchBtnText.textContent = t(cfg.btnKey, cfg.btn || '');
}
function openClientCard(version) {
const cfg = CLIENTS[version] || CLIENTS['1.21.4'];
selectedVersion = version;
if (detailTitle) detailTitle.textContent = version;
if (detailSubtitle) detailSubtitle.textContent = t(cfg.subtitleKey, cfg.subtitle || '');
if (detailDescription) detailDescription.textContent = t(cfg.descKey, cfg.desc || '');
if (detailBanner) detailBanner.style.background = "url('" + (cfg.bgBanner || cfg.bg) + "') center/cover no-repeat";
if (launchBtnText) launchBtnText.textContent = t(cfg.btnKey, cfg.btn || '');
if (launchBtn) {
launchBtn.disabled = !!cfg.disabled;
launchBtn.style.cursor = cfg.disabled ? 'not-allowed' : '';
launchBtn.style.opacity = cfg.disabled ? '.55' : '';
}
if (screenMain) { screenMain.style.display = 'none'; screenMain.classList.remove('active'); }
if (clientDetailScreen) {
clientDetailScreen.style.display = 'flex';
setTimeout(() => { clientDetailScreen.classList.add('active'); }, 10);
}
}
const uploadAvatarBtn = document.getElementById('uploadAvatarBtn');
const winMinimize = document.getElementById('windowMinimize');
const winClose = document.getElementById('windowClose');
const logoutBtn = document.getElementById('logoutBtn');
const sidebarEl = document.getElementById('sidebar') || document.querySelector('.sidebar');
const sidebarToggleBtn = document.getElementById('sidebarToggle');
if (sidebarEl && sidebarToggleBtn) {
sidebarToggleBtn.addEventListener('click', () => {
const expanded = sidebarEl.classList.toggle('expanded');
sidebarToggleBtn.classList.toggle('is-expanded', expanded);
sidebarToggleBtn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
});
}
if (winMinimize) winMinimize.addEventListener('click', () => ipcRenderer.send('window-minimize'));
if (winClose) winClose.addEventListener('click', () => ipcRenderer.send('window-close'));
if (uploadAvatarBtn) {
uploadAvatarBtn.addEventListener('click', () => ipcRenderer.send('open-avatar-dialog'));
}
ipcRenderer.on('selected-avatar', (event, avatarPath) => {
const formattedPath = avatarPath.replace(/\\/g, '/');
if (userAvatar) userAvatar.style.backgroundImage = `url('file://${formattedPath}')`;
try {
const img = new Image();
img.onload = () => {
const canvas = document.createElement('canvas');
canvas.width = 128;
canvas.height = 128;
canvas.getContext('2d').drawImage(img, 0, 0, 128, 128);
localStorage.setItem('nebula_avatar', canvas.toDataURL('image/png'));
};
img.src = `file://${formattedPath}`;
} catch (e) { console.error(e); }
});
clientCards.forEach(card => {
card.addEventListener('click', () => {
openClientCard(card.dataset.version || '1.21.4');
});
});
if (backToCardsBtn) {
backToCardsBtn.addEventListener('click', () => {
if (clientDetailScreen) { clientDetailScreen.style.display = 'none'; clientDetailScreen.classList.remove('active'); }
if (screenMain) {
screenMain.style.display = 'block';
setTimeout(() => { screenMain.classList.add('active'); }, 10);
}
});
}
const VERSION_ARG = (function () {
try {
const arg = (process.argv || []).find(x => x && x.indexOf('--version=') === 0);
if (arg) { const v = arg.slice('--version='.length); if (CLIENTS[v]) return v; }
} catch (e) { }
return null;
})();
if (VERSION_ARG) {
let versionOpened = false;
const versionTimer = setInterval(() => {
if (versionOpened) { clearInterval(versionTimer); return; }
const authEl = document.getElementById('authOverlay');
const verifyEl = document.getElementById('verifyOverlay');
const overlaysHidden = (!authEl || authEl.classList.contains('hidden')) &&
(!verifyEl || verifyEl.classList.contains('hidden'));
const mainScreenEl = document.getElementById('screen-main');
const mainVisible = mainScreenEl && (mainScreenEl.style.display === 'block' ||
mainScreenEl.classList.contains('active'));
if (!overlaysHidden || !mainVisible) return;
versionOpened = true;
clearInterval(versionTimer);
openClientCard(VERSION_ARG);
}, 300);
}
const launchStatus = document.getElementById('launch-status');
function setLaunchUI(state, msg) {
if (state === 'checking') {
if (launchBtnText) launchBtnText.textContent = '\u041f\u0420\u041e\u0412\u0415\u0420\u041a\u0410';
if (launchStatus) launchStatus.textContent = msg || '\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432...';
if (launchBtn) launchBtn.disabled = true;
} else if (state === 'installing') {
if (launchBtnText) launchBtnText.textContent = '\u0423\u0421\u0422\u0410\u041d\u041e\u0412\u041a\u0410';
if (launchStatus) launchStatus.textContent = msg || '\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u043d\u0443\u0436\u043d\u044b\u0445 \u0444\u0430\u0439\u043b\u043e\u0432...';
if (launchBtn) launchBtn.disabled = true;
} else if (state === 'starting') {
if (launchBtnText) launchBtnText.textContent = '\u0417\u0410\u041f\u0423\u0421\u041a';
if (launchStatus) launchStatus.textContent = msg || '\u0417\u0430\u043f\u0443\u0441\u043a Minecraft 1.21.4...';
if (launchBtn) launchBtn.disabled = true;
} else {
if (launchBtnText) launchBtnText.textContent = '\u0417\u0410\u041f\u0423\u0421\u0422\u0418\u0422\u042c';
if (launchStatus) launchStatus.textContent = msg || '';
if (launchBtn) launchBtn.disabled = false;
}
}
if (ipcRenderer && ipcRenderer.on) {
ipcRenderer.on('launch-status', (event, msg) => {
if (!launchStatus) return;
launchStatus.textContent = msg || '';
launchStatus.className = 'launch-status';
if (msg) {
if (/обновлен|обновление/i.test(msg)) {
launchStatus.classList.add('status-update');
if (launchBtnText) launchBtnText.textContent = '\u041e\u0411\u041d\u041e\u0412\u0418\u0422\u042c';
} else if (/ошибка/i.test(msg)) {
launchStatus.classList.add('status-missing');
} else if (/запущен|запуска|Запуск/i.test(msg)) {
launchStatus.classList.add('status-launching');
} else if (/проверк/i.test(msg)) {
launchStatus.classList.add('status-checking');
} else {
launchStatus.classList.add('status-downloading');
}
}
});
ipcRenderer.on('launch-done', () => {
if (launchBtnText) launchBtnText.textContent = '\u0417\u0410\u041f\u0423\u0421\u0422\u0418\u0422\u042c';
if (launchBtn) launchBtn.disabled = false;
});
}
if (launchBtn) {
launchBtn.addEventListener('click', () => {
if (launchBtn.disabled) return;
const session = getSession();
if (!session || !session.username) { showAuthOverlay(); return; }
const username = session.username;
const ram = localStorage.getItem('nebula_ram') || '2048';
setLaunchUI('checking');
ipcRenderer.send('launch-game', username, ram, selectedVersion);
});
}
ipcRenderer.send('get-hwid');
ipcRenderer.on('hwid', (event, hwid) => {
const el = document.getElementById('hwidValue');
if (el && hwid) el.textContent = hwid;
});
const mcNickInput = document.getElementById('mc-nick-input');
if (mcNickInput) {
const savedNick = localStorage.getItem('nebula_username');
if (savedNick) mcNickInput.value = savedNick;
mcNickInput.addEventListener('change', () => {
localStorage.setItem('nebula_username', mcNickInput.value);
});
}
function updateProfileDisplay() {
const savedUsername = localStorage.getItem('nebula_username');
if (savedUsername) {
const loginEl = document.getElementById('profile-login');
const mcNickEl = document.getElementById('profile-mc-nick');
if (loginEl) loginEl.innerText = savedUsername;
if (mcNickEl) mcNickEl.innerText = savedUsername;
}
const session = getSession();
const groupEl = document.getElementById('profile-group');
if (groupEl) applyGroupToEl(groupEl, session && session.group);
const codeInput = document.getElementById('profile-code-input');
if (codeInput && session && session.code) codeInput.value = session.code;
}
updateProfileDisplay();
if (typeof startModsPreload === 'function') { try { startModsPreload(); } catch (e) { } }
const savedAvatar = localStorage.getItem('nebula_avatar');
if (savedAvatar && userAvatar) {
userAvatar.style.backgroundImage = `url('${savedAvatar}')`;
}
const ramSliderProfile = document.getElementById('ramSliderProfile');
const ramValueProfile = document.getElementById('ramValueProfile');
const ramSliderFill = document.getElementById('ramSliderFill');
const ramSliderThumb = document.getElementById('ramSliderThumb');
const ramSliderMarks = document.getElementById('ramSliderMarks');
if (ramSliderProfile && ramValueProfile) {
const RAM_MIN = 512, RAM_STEP = 512;
let ramMax = 16384;
const RAM_CAP = 65536;
let ramValue = parseInt(localStorage.getItem('nebula_ram') || '1536', 10) || 1536;
if (ramValue < RAM_MIN) ramValue = RAM_MIN;
if (ramValue > ramMax) ramValue = ramMax;
if (ramSliderMarks) {
ramSliderMarks.innerHTML = '<span>' + (RAM_MIN / 1024) + ' \u0413\u0411</span><span>' +
(ramMax / 1024) + ' \u0413\u0411</span>';
}
function ramPaint() {
const pct = (ramValue - RAM_MIN) / (ramMax - RAM_MIN);
if (ramSliderFill) ramSliderFill.style.width = (pct * 100) + '%';
if (ramSliderThumb) ramSliderThumb.style.left = (pct * 100) + '%';
ramValueProfile.textContent = String(ramValue);
ramSliderProfile.setAttribute('aria-valuenow', String(ramValue));
}
function ramSetByClientX(clientX) {
const track = ramSliderProfile.querySelector('.ram-slider-track');
if (!track) return;
const r = track.getBoundingClientRect();
let pct = (clientX - r.left) / (r.width || 1);
if (pct < 0) pct = 0;
if (pct > 1) pct = 1;
let val = RAM_MIN + pct * (ramMax - RAM_MIN);
val = Math.round(val / RAM_STEP) * RAM_STEP;
if (val < RAM_MIN) val = RAM_MIN;
if (val > ramMax) val = ramMax;
if (val !== ramValue) {
ramValue = val;
localStorage.setItem('nebula_ram', String(ramValue));
ramPaint();
}
}
let ramDragging = false;
function ramStart(e) {
ramDragging = true;
ramSliderProfile.classList.add('is-dragging');
ramSetByClientX(e.touches ? e.touches[0].clientX : e.clientX);
if (e.cancelable) e.preventDefault();
}
function ramMove(e) {
if (!ramDragging) return;
ramSetByClientX(e.touches ? e.touches[0].clientX : e.clientX);
}
function ramEnd() {
if (!ramDragging) return;
ramDragging = false;
ramSliderProfile.classList.remove('is-dragging');
}
ramSliderProfile.addEventListener('mousedown', ramStart);
ramSliderProfile.addEventListener('touchstart', ramStart, { passive: false });
window.addEventListener('mousemove', ramMove);
window.addEventListener('touchmove', ramMove, { passive: false });
window.addEventListener('mouseup', ramEnd);
window.addEventListener('touchend', ramEnd);
ramSliderProfile.addEventListener('keydown', (e) => {
let d = 0;
if (e.key === 'ArrowRight' || e.key === 'ArrowUp') d = RAM_STEP;
if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') d = -RAM_STEP;
if (e.key === 'PageUp') d = RAM_STEP * 4;
if (e.key === 'PageDown') d = -RAM_STEP * 4;
if (!d) return;
e.preventDefault();
let v = ramValue + d;
if (v < RAM_MIN) v = RAM_MIN;
if (v > ramMax) v = ramMax;
ramValue = v;
localStorage.setItem('nebula_ram', String(ramValue));
ramPaint();
});
ramPaint();
// Автоопределение ОЗУ: показываем реальную память и ограничиваем слайдер
try {
ipcRenderer.invoke('sys:info').then((info) => {
if (!info || !info.totalMB || !ramSliderProfile) return;
const sysMax = Math.floor(info.totalMB / RAM_STEP) * RAM_STEP;
const capped = Math.max(RAM_MIN, Math.min(RAM_CAP, sysMax));
if (capped > RAM_MIN) {
ramMax = capped;
if (ramSliderMarks) {
ramSliderMarks.innerHTML = '<span>' + (RAM_MIN / 1024) + ' ГБ</span><span>' + (ramMax / 1024) + ' ГБ</span>';
}
ramSliderProfile.setAttribute('aria-valuemax', String(ramMax));
if (ramValue > ramMax) {
ramValue = ramMax;
localStorage.setItem('nebula_ram', String(ramValue));
}
ramPaint();
}
const sysInfo = document.getElementById('ramSystemInfo');
if (sysInfo) {
const gb = Math.round((info.totalMB / 1024) * 10) / 10;
sysInfo.textContent = 'На вашем ПК: ' + (info.totalMB >= 1024 ? (gb + ' ГБ ОЗУ') : (info.totalMB + ' МБ ОЗУ')) + ' · ядер: ' + (info.cpus || 1);
}
}).catch(() => { });
} catch (e) { }
// внешняя установка значения (кнопка «Слабый ПК»)
window.setRamExternal = function (val) {
let v = parseInt(val, 10) || 1536;
if (v < RAM_MIN) v = RAM_MIN;
if (v > ramMax) v = ramMax;
ramValue = v;
localStorage.setItem('nebula_ram', String(ramValue));
ramPaint();
};
}
// ===== Кнопка «Слабый ПК» — оптимизация в один клик =====
const weakPcBtn = document.getElementById('weakPcBtn');
const weakPcStatus = document.getElementById('weakPcStatus');
if (weakPcBtn && weakPcStatus) {
let weakBusy = false;
weakPcBtn.addEventListener('click', async () => {
if (weakBusy) return;
weakBusy = true;
weakPcBtn.disabled = true;
const originalText = weakPcBtn.textContent;
weakPcBtn.textContent = 'ОПТИМИЗАЦИЯ…';
weakPcStatus.style.color = '';
weakPcStatus.textContent = 'Подготовка…';
try {
const target = selectedVersion || '1.21.4';
const res = await ipcRenderer.invoke('weakpc:apply', { version: target });
if (res && res.ok) {
if (typeof window.setRamExternal === 'function') window.setRamExternal(res.ram);
weakPcStatus.style.color = '#3ddc84';
weakPcStatus.textContent = 'Готово! Моды установлены. ОЗУ выделено: ' + (res.ram / 1024) + ' ГБ';
} else {
const err = res && (res.error || ((res.failed || []).join('; ')));
weakPcStatus.textContent = 'Частично: ' + (err || 'не удалось скачать моды');
weakPcStatus.style.color = '#ffb4b4';
}
} catch (e) {
weakPcStatus.textContent = 'Ошибка: ' + ((e && e.message) || e);
weakPcStatus.style.color = '#ffb4b4';
} finally {
weakBusy = false;
weakPcBtn.disabled = false;
weakPcBtn.textContent = originalText;
}
});
ipcRenderer.on('weakpc:progress', (event, d) => {
if (!d) return;
if (d.stage === 'ram') {
weakPcStatus.textContent = 'ОЗУ → ' + (d.ram / 1024) + ' ГБ (всего ' + d.totalGb + ' ГБ)…';
} else if (d.stage === 'progress') {
weakPcStatus.textContent = 'Скачиваю ' + d.name + ' (' + d.done + ' из ' + d.total + ')…';
}
});
}
if (logoutBtn) {
logoutBtn.addEventListener('click', () => {
clearSession();
localStorage.removeItem('nebula_username');
localStorage.removeItem('nebula_avatar');
if (mcNickInput) mcNickInput.value = '';
const loginEl = document.getElementById('profile-login');
const mcNickEl = document.getElementById('profile-mc-nick');
const groupEl = document.getElementById('profile-group');
if (loginEl) loginEl.innerText = 'Player';
if (mcNickEl) mcNickEl.innerText = 'Player';
if (groupEl) applyGroupToEl(groupEl, '');
showAuthOverlay();
});
}
const resetHwidBtn = document.getElementById('resetHwidBtn');
const profileMsg = document.getElementById('profile-msg');
const profileCodeInput = document.getElementById('profile-code-input');
function setProfileMsg(text, kind) {
if (!profileMsg) return;
profileMsg.textContent = text || '';
profileMsg.className = 'profile-msg' + (kind ? ' ' + kind : '');
}
if (resetHwidBtn) {
resetHwidBtn.addEventListener('click', async () => {
const session = getSession();
if (!session || !session.username) { setProfileMsg(t('msg_need_login', '\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u043e\u0439\u0434\u0438\u0442\u0435 \u0432 \u0430\u043a\u043a\u0430\u0443\u043d\u0442'), 'err'); return; }
const code = (profileCodeInput && profileCodeInput.value.trim()) || '';
resetHwidBtn.disabled = true;
setProfileMsg(t('msg_loading', '\u0421\u0431\u0440\u0430\u0441\u044b\u0432\u0430\u0435\u043c \u043f\u0440\u0438\u0432\u044f\u0437\u043a\u0443...'));
const res = await ipcRenderer.invoke('auth:resetHwid', {
username: session.username,
password: '',
code: code
});
resetHwidBtn.disabled = false;
if (!res || !res.ok) {
setProfileMsg((res && res.error) || t('msg_hw_reset_err', '\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u0431\u0440\u043e\u0441\u0438\u0442\u044c HWID'), 'err');
return;
}
setProfileMsg(t('msg_hw_reset', 'HWID \u0441\u0431\u0440\u043e\u0448\u0435\u043d \u2014 \u0432\u043e\u0439\u0434\u0438\u0442\u0435 \u0437\u0430\u043d\u043e\u0432\u043e \u043d\u0430 \u044d\u0442\u043e\u043c \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435'), 'ok');
clearSession();
localStorage.removeItem('nebula_username');
showAuthOverlay();
});
}
let modsLoaded = false;
const modsSearchInput = document.getElementById('mods-search-input');
const modsSearchBtn = document.getElementById('mods-search-btn');
const modsList = document.getElementById('mods-list');
const modsStatus = document.getElementById('mods-status');
const modsMenuBackdrop = document.getElementById('mods-menu-backdrop');
const modsMenuTitle = document.getElementById('mods-menu-title');
const modsMenuDesc = document.getElementById('mods-menu-desc');
const modsMenuCancel = document.getElementById('mods-menu-cancel');
const modsDetailBackdrop = document.getElementById('mods-detail-backdrop');
const modsDetailBody = document.getElementById('mods-detail-body');
const modsDetailClose = document.getElementById('mods-detail-close');
let modsPending = null;
function setModsStatus(text, kind) {
if (!modsStatus) return;
modsStatus.textContent = text || '';
modsStatus.className = 'mods-status' + (kind ? ' ' + kind : '');
}
function fmtDownloads(n) {
n = Number(n) || 0;
if (n >= 1000000) return (n / 1000000).toFixed(1).replace('.0', '') + ' \u043c\u043b\u043d';
if (n >= 1000) return (n / 1000).toFixed(1).replace('.0', '') + ' \u0442\u044b\u0441.';
return String(n);
}
function escHtml(t) {
return String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
const MODS_ITEM_H = 71;
let modsRendered = [];
let modsScrollHandler = null;
function modItemHtml(m, idx) {
const icon = m.icon
? '<img class="mod-icon" src="' + escHtml(m.icon) + '" alt="" onerror="this.style.display=\'none\'">'
: '<div class="mod-icon"></div>';
return '<div class="mod-item" data-mod="' + escHtml(m.id) + '" title="' + escHtml(m.title) + '" style="--i:' + idx + '">' +
icon +
'<div class="mod-info">' +
'<div class="mod-title">' + escHtml(m.title) + '</div>' +
'<div class="mod-desc">' + escHtml(m.description) + '</div>' +
'<div class="mod-meta">' + escHtml(m.author ? m.author + ' \xb7 ' : '') + fmtDownloads(m.downloads) + ' \u0437\u0430\u0433\u0440\u0443\u0437\u043e\u043a</div>' +
'</div>' +
'<button class="mod-download" data-id="' + escHtml(m.id) + '" data-title="' + escHtml(m.title) + '">' + t('btn_download', '\u0421\u041a\u0410\u0427\u0410\u0422\u042c') + '</button>' +
'</div>';
}
let modsWindowKey = '';
const MODS_PAGE_ROWS = 13000;
const MODS_PAGE_H = MODS_PAGE_ROWS * MODS_ITEM_H;
let modsPageStart = 0;
function renderModsWindow(force) {
if (!modsList) return;
const total = modsRendered.length;
const space = document.getElementById('mods-scroll-space');
const inner = document.getElementById('mods-list-inner');
if (!space || !inner) return;
if (!total) {
modsWindowKey = 'empty';
space.style.height = '0px';
inner.innerHTML = '<div class="mod-empty">' + t('msg_empty', '\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u043e\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435.') + '</div>';
return;
}
const viewH = modsList.clientHeight || 320;
const localRow = Math.floor(modsList.scrollTop / MODS_ITEM_H);
let start = modsPageStart + localRow - 10;
if (start < 0) start = 0;
if (start > total - 1) start = total - 1;
const count = Math.min(total - start, Math.ceil(viewH / MODS_ITEM_H) + 20);
const key = modsPageStart + ':' + start + ':' + count + ':' + total;
if (!force && key === modsWindowKey) return;
modsWindowKey = key;
space.style.height = Math.min(total, MODS_PAGE_ROWS + 30) * MODS_ITEM_H + 'px';
const slice = modsRendered.slice(start, start + count);
inner.innerHTML = slice.map(function (m, i) { return modItemHtml(m, start + i); }).join('');
inner.style.transform = 'translateY(' + ((localRow - 10) * MODS_ITEM_H - (modsList.scrollTop - localRow * MODS_ITEM_H)) + 'px)';
}
function renderMods(list, startIndex) {
if (!modsList) return;
if (!list || !list.length) {
modsRendered = [];
modsWindowKey = 'empty';
var sp = document.getElementById('mods-scroll-space');
var inn = document.getElementById('mods-list-inner');
if (sp) sp.style.height = '0px';
if (inn) inn.innerHTML = '<div class="mod-empty">' + t('msg_empty', '\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u043e\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435.') + '</div>';
return;
}
modsRendered = list.slice();
renderModsWindow(true);
if (!modsScrollHandler) {
var scrollTimer = null;
modsScrollHandler = function () {
var l = modsList;
if (!l) return;
var maxScroll = l.scrollHeight - l.clientHeight;
if (l.scrollTop >= maxScroll - 30) {
var total = modsRendered.length;
var viewRows = Math.ceil(l.clientHeight / MODS_ITEM_H);
if (modsPageStart + MODS_PAGE_ROWS < total) {
modsPageStart += Math.floor(l.scrollTop / MODS_ITEM_H);
l.scrollTop = 0;
renderModsWindow(true);
return;
}
}
if (l.scrollTop <= 30 && modsPageStart > 0) {
var back = Math.min(modsPageStart, MODS_PAGE_ROWS);
modsPageStart -= back;
l.scrollTop = l.scrollHeight;
renderModsWindow(true);
return;
}
renderModsWindow();
if (modsLoading || modsOffset >= modsTotal) return;
if (l.scrollTop + l.clientHeight >= l.scrollHeight - 400) {
if (scrollTimer) return;
scrollTimer = setTimeout(function () {
scrollTimer = null;
fetchMods(modsQuery, modsOffset, true);
}, 250);
}
};
modsList.addEventListener('scroll', modsScrollHandler);
}
}
const MOD_CATS = [
{ id: '', t: '\u0412\u0441\u0435 \u043c\u043e\u0434\u044b', i18n: 'mods_cat_all' },
{ id: 'utility', t: '\u041f\u043e\u043c\u043e\u0449\u044c', i18n: 'mods_cat_utility' },
{ id: 'optimization', t: '\u041e\u043f\u0442\u0438\u043c\u0438\u0437\u0430\u0446\u0438\u044f', i18n: 'mods_cat_optimization' },
{ id: 'decoration', t: '\u0412\u0438\u0437\u0443\u0430\u043b\u044c\u043d\u044b\u0435 \u043c\u043e\u0434\u0443\u043b\u0438', i18n: 'mods_cat_visual' },
{ id: 'worldgen', t: '\u041c\u0438\u0440 \u0438 \u0433\u0435\u043d\u0435\u0440\u0430\u0446\u0438\u044f', i18n: 'mods_cat_worldgen' },
{ id: 'game-mechanics', t: '\u041c\u0435\u0445\u0430\u043d\u0438\u043a\u0438', i18n: 'mods_cat_mechanics' },
{ id: 'adventure', t: '\u041f\u0440\u0438\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f', i18n: 'mods_cat_adventure' },
{ id: 'technology', t: '\u0422\u0435\u0445\u043d\u043e\u043b\u043e\u0433\u0438\u0438', i18n: 'mods_cat_technology' },
{ id: 'social', t: '\u041e\u0431\u0449\u0435\u043d\u0438\u0435', i18n: 'mods_cat_social' },
{ id: 'food', t: '\u0415\u0434\u0430 \u0438 \u0444\u0435\u0440\u043c\u044b', i18n: 'mods_cat_food' },
{ id: 'library', t: '\u0411\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a\u0438', i18n: 'mods_cat_misc' }
];
let modsCat = '';
const modsCache = {};
function modsCacheKey(query, cat) { return (cat || '') + '|' + (query || ''); }
const MODS_PAGE = 100;
const MODS_AUTO_PAGES = 3;
const MODS_MORE_PAGES = 3;
let modsOffset = 0;
let modsQuery = '';
let modsTotal = 0;
let modsLoading = false;
let modsAutoRetries = 0;
async function fetchMods(query, offset, append) {
if (modsLoading) return;
modsLoading = true;
if (!append) modsAutoRetries = 0;
if (modsSearchBtn) modsSearchBtn.disabled = true;
const res = await ipcRenderer.invoke('mods:search', { query: query, cat: modsCat, limit: MODS_PAGE, offset: offset });
modsLoading = false;
if (modsSearchBtn) modsSearchBtn.disabled = false;
if (!res || !res.ok) {
setModsStatus((res && res.error) || t('msg_search_error', '\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u043e\u0438\u0441\u043a\u0430'), 'err');
if (!append) { var innerErr = document.getElementById('mods-list-inner'); if (innerErr) innerErr.innerHTML = ''; }
if (modsAutoRetries < 2) {
modsAutoRetries++;
setTimeout(() => { fetchMods(query, offset, append); }, 4000);
}
return;
}
modsTotal = res.total || 0;
const list = res.mods || [];
if (append) {
modsRendered = modsRendered.concat(list);
} else {
modsRendered = list.slice();
}
modsOffset = offset + list.length;
const ck = modsCacheKey(query, modsCat);
modsCache[ck] = { list: modsRendered.slice(), offset: modsOffset, total: modsTotal };
renderMods(modsRendered, 0);
updateModsStatus();
}
function updateModsStatus() {
setModsStatus('', '');
showMoreButton(modsRendered.length < modsTotal);
var bar = document.getElementById('mods-progress-bar');
var box = document.getElementById('mods-progress');
if (bar && box) {
var pct = modsTotal ? Math.min(100, Math.round(modsRendered.length / modsTotal * 100)) : 0;
bar.style.width = pct + '%';
if (modsRendered.length >= modsTotal && modsTotal > 0) {
box.classList.remove('is-active');
} else {
box.classList.add('is-active');
}
}
}
let modsLoadingAll = false;
async function loadAllMods() {
if (modsLoadingAll) return;
modsLoadingAll = true;
const BATCH = 4;
while (modsOffset < modsTotal) {
const offsets = [];
for (let i = 0; i < BATCH && modsOffset + i * MODS_PAGE < modsTotal; i++) {
offsets.push(modsOffset + i * MODS_PAGE);
}
const answers = await Promise.all(offsets.map(function (off) {
return ipcRenderer.invoke('mods:search', { query: modsQuery, cat: modsCat, limit: MODS_PAGE, offset: off });
}));
let added = 0;
for (let i = 0; i < answers.length; i++) {
const r = answers[i];
if (!r || !r.ok) continue;
const list = r.mods || [];
if (!list.length) continue;
modsRendered = modsRendered.concat(list);
added += list.length;
modsTotal = r.total || modsTotal;
}
if (!added) break;
modsOffset += added;
const ck = modsCacheKey(modsQuery, modsCat);
modsCache[ck] = { list: modsRendered.slice(), offset: modsOffset, total: modsTotal };
renderMods(modsRendered, 0);
updateModsStatus();
await new Promise(function (r) { setTimeout(r, 40); });
}
modsLoadingAll = false;
}
function showMoreButton(show) {
const wrap = document.getElementById('mods-more-wrap');
let btn = document.getElementById('mods-more');
if (!show) { if (btn) btn.remove(); return; }
if (!btn && wrap) {
btn = document.createElement('button');
btn.id = 'mods-more';
btn.className = 'mod-download';
btn.style.cssText = 'width:100%;margin-top:8px;padding:12px;';
btn.textContent = t('btn_load_more', '\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0435\u0449\u0451');
btn.addEventListener('click', async () => {
btn.disabled = true;
btn.textContent = t('msg_loading', '\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430...');
await loadAllMods();
btn.disabled = false;
btn.textContent = t('btn_load_more', '\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0435\u0449\u0451');
});
wrap.appendChild(btn);
}
}
let modsLiveTimer = null;
async function doModsSearch(allowEmpty) {
const q = (modsSearchInput && modsSearchInput.value.trim()) || '';
if (!q) {
if (allowEmpty) {
// Пустой поиск — возвращаемся к самым популярным модам
modsQuery = '';
const cached = modsCache[modsCacheKey('', modsCat)];
if (cached && cached.list.length) {
modsRendered = cached.list.slice();
modsOffset = cached.offset;
modsTotal = cached.total;
renderMods(modsRendered, 0);
updateModsStatus();
return;
}
modsOffset = 0;
modsRendered = [];
if (modsList) { showModsSkeleton(); modsList.scrollTop = 0; }
setModsStatus(t('msg_loading', 'Загрузка...'));
for (let i = 0; i < MODS_AUTO_PAGES; i++) {
if (i > 0 && modsOffset >= modsTotal) break;
await fetchMods('', modsOffset, i > 0);
}
if (modsOffset < modsTotal) await loadAllMods();
return;
}
setModsStatus(t('msg_enter_mod_name', 'Введите название мода'), 'err');
return;
}
modsQuery = q;
const cached = modsCache[modsCacheKey(q, modsCat)];
if (cached && cached.list.length) {
modsRendered = cached.list.slice();
modsOffset = cached.offset;
modsTotal = cached.total;
renderMods(modsRendered, 0);
updateModsStatus();
return;
}
modsOffset = 0;
modsRendered = [];
if (modsList) { showModsSkeleton(); modsList.scrollTop = 0; }
setModsStatus(t('msg_searching', 'Ищем...'));
await fetchMods(q, 0, false);
if (modsOffset < modsTotal) await loadAllMods();
}
if (modsSearchInput) {
modsSearchInput.addEventListener('input', function () {
// Живой поиск: по мере ввода показываем самые популярные подходящие моды
if (modsLiveTimer) { clearTimeout(modsLiveTimer); modsLiveTimer = null; }
modsLiveTimer = setTimeout(function () { doModsSearch(true); }, 350);
});
modsSearchInput.addEventListener('keydown', function (e) {
if (e.key === 'Enter') { e.preventDefault(); if (modsLiveTimer) { clearTimeout(modsLiveTimer); modsLiveTimer = null; } doModsSearch(false); }
});
}
if (modsSearchBtn) modsSearchBtn.addEventListener('click', function () { doModsSearch(); });
const modsCatsBox = document.getElementById('mods-cats');
function renderModCats() {
if (!modsCatsBox) return;
modsCatsBox.innerHTML = MOD_CATS.map(function (c) {
return '<div class="mods-cat' + (c.id === modsCat ? ' active' : '') + '" data-cat="' + c.id + '">' + t(c.i18n, c.t) + '</div>';
}).join('');
}
if (modsCatsBox) {
modsCatsBox.addEventListener('wheel', function (e) {
if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
if (modsList) { modsList.scrollTop += e.deltaY; }
e.preventDefault();
}
}, { passive: false });
modsCatsBox.addEventListener('click', async function (e) {
const el = e.target.closest ? e.target.closest('.mods-cat') : null;
if (!el) return;
const cat = el.getAttribute('data-cat') || '';
if (cat === modsCat) return;
modsCat = cat;
renderModCats();
modsQuery = (modsSearchInput && modsSearchInput.value.trim()) || '';
const cached = modsCache[modsCacheKey(modsQuery, modsCat)];
if (cached && cached.list.length) {
modsRendered = cached.list.slice();
modsOffset = cached.offset;
modsTotal = cached.total;
renderMods(modsRendered, 0);
updateModsStatus();
return;
}
modsOffset = 0;
modsRendered = [];
if (modsList) { showModsSkeleton(); modsList.scrollTop = 0; }
setModsStatus(t('msg_loading', '\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430...'));
for (let i = 0; i < MODS_AUTO_PAGES; i++) {
if (i > 0 && modsOffset >= modsTotal) break;
await fetchMods(modsQuery, modsOffset, i > 0);
}
if (modsOffset < modsTotal) await loadAllMods();
});
renderModCats();
}
let modsPreloadPromise = null;
function startModsPreload() {
if (modsPreloadPromise) return modsPreloadPromise;
modsPreloadPromise = (async function () {
const cached = modsCache[modsCacheKey('', '')];
if (cached && cached.list.length) return;
for (let i = 0; i < MODS_AUTO_PAGES; i++) {
if (i > 0 && modsOffset >= modsTotal) break;
await fetchMods('', modsOffset, i > 0);
}
})();
return modsPreloadPromise;
}
if (modsList) {
modsList.addEventListener('click', function (e) {
const btn = e.target.closest ? e.target.closest('.mod-download') : null;
if (btn) {
modsPending = { id: btn.getAttribute('data-id'), title: btn.getAttribute('data-title') };
if (modsMenuTitle) modsMenuTitle.textContent = modsPending.title;
if (modsMenuDesc) modsMenuDesc.textContent = '\u041a\u0443\u0434\u0430 \u0441\u043a\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434 "' + modsPending.title + '"?';
if (modsMenuBackdrop) modsMenuBackdrop.hidden = false;
return;
}
const item = e.target.closest ? e.target.closest('.mod-item') : null;
if (item) {
const id = item.getAttribute('data-mod');
if (id) openModCard(id);
}
});
}
async function openModCard(id) {
if (!id || !modsDetailBackdrop) return;
if (modsDetailBody) modsDetailBody.innerHTML = '<div class="mods-detail-loading">' + t('msg_loading', '\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430...') + '</div>';
if (modsDetailBackdrop) modsDetailBackdrop.hidden = false;
const res = await ipcRenderer.invoke('mods:project', { id: id });
if (!modsDetailBody) return;
if (!res || !res.ok) {
modsDetailBody.innerHTML = '<div class="mods-detail-error">' + escHtml((res && res.error) || t('msg_mod_error', '\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438 \u043c\u043e\u0434\u0430')) + '</div>';
return;
}
const m = res.mod || {};
const gallery = (m.gallery || []).slice(0, 4);
const mainImg = m.icon || (gallery[0] && gallery[0].url) || '';
const images = gallery.map(function (g) {
return '<img class="mods-detail-thumb" src="' + escHtml(g.url) + '" alt="" onerror="this.style.display=\'none\'">';
}).join('');
if (modsDetailBody) {
modsDetailBody.innerHTML =
'<div class="mods-detail-head">' +
(mainImg ? '<img class="mods-detail-img" src="' + escHtml(mainImg) + '" alt="" onerror="this.style.display=\'none\'">' : '<div class="mods-detail-img mods-detail-img-empty"></div>') +
'<div class="mods-detail-headtext">' +
'<div class="mods-detail-title">' + escHtml(m.title || '') + '</div>' +
'<div class="mods-detail-author">\u0410\u0432\u0442\u043e\u0440: ' + escHtml(m.author || '—') + '</div>' +
'<div class="mods-detail-meta">' + fmtDownloads(m.downloads) + ' \u0437\u0430\u0433\u0440\u0443\u0437\u043e\u043a \xb7 ' + fmtDownloads(m.follows) + ' \u043f\u043e\u0434\u043f\u0438\u0441\u0447\u0438\u043a\u043e\u0432</div>' +
'</div></div>' +
(images ? '<div class="mods-detail-gallery">' + images + '</div>' : '') +
'<div class="mods-detail-desc">' + escHtml(m.description || '') + '</div>' +
'<div class="mods-detail-cats">' + ((m.categories || []).slice(0, 6).map(function (c) {
return '<span class="mods-detail-cat">' + escHtml(c) + '</span>';
}).join('')) + '</div>' +
'<button class="mods-detail-download" id="mods-detail-download">\u0421\u041a\u0410\u0427\u0410\u0422\u042c</button>';
}
const dlBtn = document.getElementById('mods-detail-download');
if (dlBtn) {
dlBtn.addEventListener('click', function () {
modsPending = { id: id, title: (res.mod && res.mod.title) || '' };
if (modsDetailBackdrop) modsDetailBackdrop.hidden = true;
if (modsMenuTitle) modsMenuTitle.textContent = modsPending.title;
if (modsMenuDesc) modsMenuDesc.textContent = '\u041a\u0443\u0434\u0430 \u0441\u043a\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434 "' + modsPending.title + '"?';
if (modsMenuBackdrop) modsMenuBackdrop.hidden = false;
});
}
}
if (modsDetailClose) {
modsDetailClose.addEventListener('click', function () {
if (modsDetailBackdrop) modsDetailBackdrop.hidden = true;
});
}
if (modsDetailBackdrop) {
modsDetailBackdrop.addEventListener('click', function (e) {
if (e.target === modsDetailBackdrop) modsDetailBackdrop.hidden = true;
});
}
if (modsMenuCancel) {
modsMenuCancel.addEventListener('click', function () {
if (modsMenuBackdrop) modsMenuBackdrop.hidden = true;
modsPending = null;
});
}
if (modsMenuBackdrop) {
modsMenuBackdrop.addEventListener('click', function (e) {
if (e.target === modsMenuBackdrop) {
modsMenuBackdrop.hidden = true;
modsPending = null;
}
});
}
if (modsMenuBackdrop) {
modsMenuBackdrop.querySelectorAll('.mods-version-btn').forEach(function (btn) {
btn.addEventListener('click', async function () {
if (!modsPending) return;
const mc = btn.getAttribute('data-ver');
const mod = modsPending;
btn.disabled = true;
setModsStatus(tf('msg_downloading', '\u0421\u043a\u0430\u0447\u0438\u0432\u0430\u0435\u043c \u043c\u043e\u0434 \u0434\u043b\u044f {0}...', [mc]));
const res = await ipcRenderer.invoke('mods:download', { id: mod.id, mc: mc });
btn.disabled = false;
if (!res || !res.ok) {
setModsStatus((res && res.error) || t('msg_mod_error', '\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438'), 'err');
return;
}
modsMenuBackdrop.hidden = true;
modsPending = null;
const kb = Math.round((res.size || 0) / 1024);
setModsStatus(tf('msg_mod_installed', '\u041c\u043e\u0434 {0} \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d \u0432 \u0441\u0431\u043e\u0440\u043a\u0443 {1} ({2} \u041a\u0411)', [res.file, mc, kb]), 'ok');
});
});
}
navItems.forEach(item => {
item.addEventListener('click', async () => {
navItems.forEach(nav => nav.classList.remove('active'));
item.classList.add('active');
const targetScreen = item.getAttribute('data-target');
if (targetScreen === 'screen-mods') {
if (!modsLoaded) {
modsLoaded = true;
renderModCats();
if (modsRendered.length) {
renderMods(modsRendered, 0);
updateModsStatus();
} else {
showModsSkeleton();
setModsStatus(t('msg_loading', '\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043c\u043e\u0434\u043e\u0432...'));
await startModsPreload();
renderMods(modsRendered, 0);
updateModsStatus();
if (modsOffset < modsTotal) loadAllMods();
}
} else if (modsRendered.length) {
renderMods(modsRendered, 0);
updateModsStatus();
}
}
if (clientDetailScreen) { clientDetailScreen.style.display = 'none'; clientDetailScreen.classList.remove('active'); }
screens.forEach(screen => {
screen.style.display = '';
screen.classList.remove('active');
});
if (targetScreen) {
const targetEl = document.getElementById(targetScreen);
if (targetEl) {
targetEl.classList.add('active');
setTimeout(() => { targetEl.classList.add('active'); }, 5);
}
}
});
});
});
try {
ipcRenderer.invoke('instance-info').then(function (info) {
var n = info && info.instance ? info.instance : 1;
var badge = document.getElementById('instanceBadge');
if (badge) {
if (n > 1) {
badge.textContent = '\u041e\u041a\u041d\u041e #' + n;
badge.style.display = '';
} else {
badge.style.display = 'none';
}
}
}).catch(function () { });
} catch (e) { }