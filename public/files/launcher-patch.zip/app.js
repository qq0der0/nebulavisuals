/* nvPROTECTED */
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
let win;
let authWindow;
let PKG_VERSION = '1.1.0';
try {
const pkg = require(path.join(__dirname, 'package.json'));
if (pkg && pkg.version) PKG_VERSION = pkg.version;
} catch (e) { }
const CACHE_DIR = 'C:\\NebulaVisuals\\cache';
const GAME_ROOT = 'C:\\NebulaVisuals\\game';
const GAME_PATH = 'C:\\NebulaVisuals\\game\\1.21.4';
let INSTANCE = 1;
let instanceLock = '';
function isProcessAlive(pid) {
try { process.kill(pid, 0); return true; } catch (e) { return e && e.code === 'EPERM'; }
}
function detectInstance() {
try { ensureDir(GAME_ROOT); } catch (e) { }
for (let num = 1; num <= 32; num++) {
const lock = path.join(GAME_ROOT, '.instance-' + num + '.lock');
const gameFile = path.join(GAME_ROOT, '.instance-' + num + '.game');
let busy = false;
try {
if (fs.existsSync(lock)) {
const pid = parseInt(fs.readFileSync(lock, 'utf8').trim(), 10);
if (pid && isProcessAlive(pid)) busy = true;
else { try { fs.unlinkSync(lock); } catch (e) { } }
}
} catch (e) { busy = true; }
if (!busy) {
try {
if (fs.existsSync(gameFile)) {
const gpid = parseInt(fs.readFileSync(gameFile, 'utf8').trim(), 10);
if (gpid && isProcessAlive(gpid)) busy = true;
else { try { fs.unlinkSync(gameFile); } catch (e) { } }
}
} catch (e) { }
}
if (busy) continue;
try { fs.writeFileSync(lock, String(process.pid)); instanceLock = lock; } catch (e) { }
return num;
}
return 1;
}
function markGameRunning(num, pid) {
try {
fs.writeFileSync(path.join(GAME_ROOT, '.instance-' + num + '.game'), String(pid || 0));
} catch (e) { }
}
function releaseInstance() {
try { if (instanceLock && fs.existsSync(instanceLock)) fs.unlinkSync(instanceLock); } catch (e) { }
}
process.on('exit', releaseInstance);
process.on('uncaughtException', function (e) { releaseInstance(); console.error(e); });
function gamePathFor(slot, version) {
const base = path.join(GAME_ROOT, version);
return (slot && slot > 1) ? base + '-' + slot : base;
}
function instancePath(version) {
return gamePathFor(INSTANCE, version);
}
function slotFree(num) {
const files = [
path.join(GAME_ROOT, '.instance-' + num + '.lock'),
path.join(GAME_ROOT, '.instance-' + num + '.game')
];
for (const f of files) {
try {
if (!fs.existsSync(f)) continue;
const pid = parseInt(fs.readFileSync(f, 'utf8').trim(), 10);
if (pid && isProcessAlive(pid)) return false;
} catch (e) { }
}
return true;
}
function gameSlotFree(num) {
const gameFile = path.join(GAME_ROOT, '.instance-' + num + '.game');
try {
if (!fs.existsSync(gameFile)) return true;
const pid = parseInt(fs.readFileSync(gameFile, 'utf8').trim(), 10);
if (pid && isProcessAlive(pid)) return false;
try { fs.unlinkSync(gameFile); } catch (e) { }
return true;
} catch (e) { return true; }
}
function freeSlotForLaunch() {
if (gameSlotFree(INSTANCE)) return INSTANCE;
for (let num = 1; num <= 32; num++) {
if (num === INSTANCE) continue;
if (slotFree(num)) return num;
}
return INSTANCE;
}
function cachePath(rel) { return path.join(CACHE_DIR, rel); }
function linkTree(src, dst) {
let made = 0;
let st;
try { st = fs.statSync(src); } catch (e) { return 0; }
if (st.isDirectory()) {
ensureDir(dst);
let names = [];
try { names = fs.readdirSync(src); } catch (e) { names = []; }
for (const name of names) made += linkTree(path.join(src, name), path.join(dst, name));
return made;
}
if (!st.isFile()) return 0;
if (fs.existsSync(dst)) return 0;
try { fs.linkSync(src, dst); return 1; } catch (e) { }
try { ensureDir(path.dirname(dst)); fs.copyFileSync(src, dst); return 1; } catch (e) { }
return 0;
}
function copyTree(src, dst) {
let made = 0;
let st;
try { st = fs.statSync(src); } catch (e) { return 0; }
if (st.isDirectory()) {
ensureDir(dst);
let names = [];
try { names = fs.readdirSync(src); } catch (e) { names = []; }
for (const name of names) made += copyTree(path.join(src, name), path.join(dst, name));
return made;
}
if (!st.isFile()) return 0;
if (fs.existsSync(dst)) return 0;
try { ensureDir(path.dirname(dst)); fs.copyFileSync(src, dst); return 1; } catch (e) { }
return 0;
}
function seedInstanceFiles(versionId, slot) {
const target = slot || INSTANCE;
if (target <= 1) return { seeded: false, reason: 'primary' };
const primary = path.join(GAME_ROOT, versionId);
const inst = gamePathFor(target, versionId);
if (primary.toLowerCase() === inst.toLowerCase()) return { seeded: false, reason: 'same' };
if (!fs.existsSync(primary)) return { seeded: false, reason: 'no-primary' };
const marker = path.join(inst, '.seeded');
if (isRealFile(marker)) return { seeded: false, reason: 'done' };
ensureDir(inst);
let made = 0;
const bigDirs = ['libraries', 'assets', 'java'];
for (const d of bigDirs) {
const src = path.join(primary, d);
const dst = path.join(inst, d);
if (!fs.existsSync(src) || fs.existsSync(dst)) continue;
try { fs.symlinkSync(src, dst, 'junction'); made++; }
catch (e) { try { if (linkTree(src, dst) > 0) made++; } catch (e2) { } }
}
const nativeSrc = path.join(primary, 'natives');
if (fs.existsSync(nativeSrc)) {
try { if (linkTree(nativeSrc, path.join(inst, 'natives')) > 0) made++; } catch (e) { }
}
const modsSrc = path.join(primary, 'mods');
if (fs.existsSync(modsSrc)) {
try { if (copyTree(modsSrc, path.join(inst, 'mods')) > 0) made++; } catch (e) { }
}
try { fs.writeFileSync(marker, 'instance ' + INSTANCE + '\n' + new Date().toISOString()); } catch (e) { }
return { seeded: true, made: made };
}
const SELFTEST_NO_LAUNCH = process.argv.indexOf('--no-launch') !== -1;
function ensureDir(dir) {
if (!fs.existsSync(dir)) {
fs.mkdirSync(dir, { recursive: true });
}
}
function createWindow() {
win = new BrowserWindow({
width: 1270, height: 820,
minWidth: 1100, minHeight: 700,
resizable: true, maximizable: true, fullscreenable: false,
frame: false, fullscreen: false, show: false,
icon: path.join(__dirname, 'icon.ico'),
webPreferences: { nodeIntegration: true, contextIsolation: false }
});
win.on('enter-full-screen', (event) => {
event.preventDefault();
win.webContents.setFullScreen(false);
});
win.loadFile('index.html');
win.once('ready-to-show', () => {
try { win.show(); win.focus(); } catch (e) { }
});
}
function createAuthWindow() {
authWindow = new BrowserWindow({
width: 500, height: 780, resizable: false, frame: false, fullscreen: false, show: false,
minWidth: 500, minHeight: 780,
backgroundColor: '#07080f', fullscreenable: false,
icon: path.join(__dirname, 'icon.ico'),
webPreferences: { nodeIntegration: true, contextIsolation: false },
alwaysOnTop: false
});
authWindow.once('ready-to-show', () => {
try { authWindow.show(); } catch (e) { }
});
authWindow.on('enter-full-screen', (event) => {
event.preventDefault();
authWindow.webContents.setFullScreen(false);
});
authWindow.loadFile('login.html');
authWindow.on('closed', () => { authWindow = null; });
}
ipcMain.on('window-minimize', () => { if (win) win.minimize(); });
ipcMain.on('window-exit-fullscreen', () => { if (win) { try { win.setFullScreen(false); } catch (e) { } } });
ipcMain.handle('instance-info', () => ({ instance: INSTANCE }));
ipcMain.on('window-close', () => { if (win) win.close(); });
ipcMain.on('auth-win-minimize', () => { if (authWindow) authWindow.minimize(); });
ipcMain.on('auth-win-close', () => { if (authWindow) authWindow.close(); });
ipcMain.on('auth-window:success', (event, user) => {
try { if (authWindow) { authWindow.close(); authWindow = null; } } catch (e) { }
if (win) {
win.webContents.send('session:ready', user);
win.show();
win.focus();
}
});
ipcMain.on('open-avatar-dialog', (event) => {
dialog.showOpenDialog(win, {
title: '\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u0432\u0430\u0442\u0430\u0440\u043a\u0443', defaultPath: app.getPath('pictures'),
buttonLabel: '\u041e\u0442\u043a\u0440\u044b\u0442\u044c',
filters: [{ name: '\u0418\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f', extensions: ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'] }],
properties: ['openFile']
}).then(result => {
if (!result.canceled && result.filePaths.length > 0) event.reply('selected-avatar', result.filePaths[0]);
}).catch(err => console.log(err));
});
ipcMain.on('get-hwid', (event) => {
try {
event.reply('hwid', getOrCreateHwid());
} catch (e) {
event.reply('hwid', '\u041e\u0428\u0418\u0411\u041a\u0410');
}
});
const AUTH_API = 'https://nebulavisuals-public.vercel.app/api/chat';
function apiPost(payload) {
return new Promise((resolve) => {
let done = false;
const finish = (v) => { if (done) return; done = true; resolve(v); };
try {
const data = Buffer.from(JSON.stringify(payload), 'utf8');
const u = new URL(AUTH_API);
const req = https.request({
hostname: u.hostname,
path: u.pathname,
method: 'POST',
headers: { 'Content-Type': 'application/json', 'Content-Length': data.length }
}, (res) => {
let body = '';
res.on('data', (c) => { body += c; });
res.on('end', () => {
try { finish(JSON.parse(body)); }
catch (e) { finish({ ok: false, error: '\u041d\u0435\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u0441\u0435\u0440\u0432\u0435\u0440\u0430' }); }
});
});
req.setTimeout(9000, () => { try { req.destroy(); } catch (e) {} finish({ ok: false, error: '\u0421\u0435\u0440\u0432\u0435\u0440 \u043d\u0435 \u043e\u0442\u0432\u0435\u0447\u0430\u0435\u0442', network: true }); });
req.on('error', () => finish({ ok: false, error: '\u041d\u0435\u0442 \u0441\u0432\u044f\u0437\u0438 \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043e\u043c', network: true }));
req.write(data);
req.end();
} catch (e) {
finish({ ok: false, error: '\u041e\u0448\u0438\u0431\u043a\u0430 \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u0430\u0446\u0438\u0438' });
}
});
}
function groupLabel(role) {
if (typeof role === 'string' && role) return role;
const parts = [];
if (role && role.indexOf('admin') !== -1) parts.push('admin');
if (role && role.indexOf('coder') !== -1) parts.push('coder');
if (role && role.indexOf('tester') !== -1) parts.push('tester');
return parts.length ? parts.join(' \u2020 ') : '';
}
ipcMain.handle('auth:login', async (event, credentials) => {
const username = String((credentials && credentials.username) || '').trim();
const password = String((credentials && credentials.password) || '');
const code = String((credentials && credentials.code) || '').trim();
if (!username || !password) return { ok: false, error: '\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043d\u0438\u043a \u0438 \u043f\u0430\u0440\u043e\u043b\u044c' };
const hwid = getOrCreateHwid();
const payload = { authOp: 'login', username: username, password: password };
if (code) payload.code = code;
let res = await apiPost(payload);
if (!res || !res.ok) {
await new Promise((r) => setTimeout(r, 700));
res = await apiPost(payload);
}
if (!res || !res.ok) return { ok: false, error: (res && res.error) || '\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043d\u0438\u043a \u0438\u043b\u0438 \u043f\u0430\u0440\u043e\u043b\u044c' };
const u = res.user || {};
if (u.hwid && String(u.hwid).toUpperCase() !== String(hwid).toUpperCase()) {
return { ok: false, error: '\u0410\u043a\u043a\u0430\u0443\u043d\u0442 \u043f\u0440\u0438\u0432\u044f\u0437\u0430\u043d \u043a \u0434\u0440\u0443\u0433\u043e\u043c\u0443 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0443', needResetHwid: true };
}
if (!u.hwid) {
try {
const br = await apiPost({ authOp: 'bind', username: u.username, hwid: hwid });
if (br && br.ok === false && br.hwid) {
return { ok: false, error: '\u0410\u043a\u043a\u0430\u0443\u043d\u0442 \u043f\u0440\u0438\u0432\u044f\u0437\u0430\u043d \u043a \u0434\u0440\u0443\u0433\u043e\u043c\u0443 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0443', needResetHwid: true };
}
} catch (e) { }
}
return {
ok: true,
user: {
username: u.username,
email: u.email || '',
role: u.role || '',
group: groupLabel(u.role || ''),
hwid: hwid
}
};
});
ipcMain.handle('auth:register', async (event, credentials) => {
const username = String((credentials && credentials.username) || '').trim();
const email = String((credentials && credentials.email) || '').trim().toLowerCase();
const password = String((credentials && credentials.password) || '');
if (!username || !email || !password) return { ok: false, error: '\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0432\u0441\u0435 \u043f\u043e\u043b\u044f' };
const hwid = getOrCreateHwid();
const res = await apiPost({ authOp: 'register', username: username, email: email, password: password });
if (!res || !res.ok) return { ok: false, error: (res && res.error) || '\u041e\u0448\u0438\u0431\u043a\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438' };
const u = res.user || {};
try { await apiPost({ authOp: 'bind', username: u.username, hwid: hwid }); } catch (e) { }
return {
ok: true,
user: {
username: u.username,
email: u.email || '',
role: u.role || '',
group: groupLabel(u.role || ''),
hwid: hwid
}
};
});
ipcMain.handle('auth:verify', async (event, credentials) => {
const username = String((credentials && credentials.username) || '').trim();
const password = String((credentials && credentials.password) || '');
const code = String((credentials && credentials.code) || '').trim();
if (!username || !password) return { ok: false, error: '\u041d\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u043e\u0439 \u0441\u0435\u0441\u0441\u0438\u0438' };
const hwid = getOrCreateHwid();
const payload = { authOp: 'login', username: username, password: password };
if (code) payload.code = code;
const res = await apiPost(payload);
if (!res || !res.ok) {
const isNet = !!(res && res.network);
return { ok: false, network: isNet, error: (res && res.error) || '\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u0441\u0435\u0441\u0441\u0438\u044e' };
}
const u = res.user || {};
if (u.hwid && String(u.hwid).toUpperCase() !== String(hwid).toUpperCase()) {
return { ok: false, error: '\u0410\u043a\u043a\u0430\u0443\u043d\u0442 \u043f\u0440\u0438\u0432\u044f\u0437\u0430\u043d \u043a \u0434\u0440\u0443\u0433\u043e\u043c\u0443 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0443', needResetHwid: true };
}
return {
ok: true,
user: {
username: u.username,
email: u.email || '',
role: u.role || '',
group: groupLabel(u.role || ''),
hwid: hwid
}
};
});
ipcMain.handle('auth:resetHwid', async (event, credentials) => {
const username = String((credentials && credentials.username) || '').trim();
const password = String((credentials && credentials.password) || '');
const code = String((credentials && credentials.code) || '').trim();
if (!username) return { ok: false, error: '\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u043d\u0438\u043a' };
if (!password && !code) return { ok: false, error: '\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043f\u0430\u0440\u043e\u043b\u044c \u0438\u043b\u0438 \u043a\u043e\u0434 \u0434\u043e\u0441\u0442\u0443\u043f\u0430' };
const res = await apiPost({ authOp: 'resetHwid', username: username, password: password, code: code });
if (!res || !res.ok) return { ok: false, error: (res && res.error) || '\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u0431\u0440\u043e\u0441\u0438\u0442\u044c HWID' };
return { ok: true, username: username };
});
const GAME_VERSION = '1.21.4';
const MOJANG_LIBS = 'https://libraries.minecraft.net/';
const FABRIC_MAVEN = 'https://maven.fabricmc.net/';
const CLIENT_URL = 'https://piston-data.mojang.com/v1/objects/a7e5a6024bfd3cd614625aa05629adf760020304/client.jar';
const INDEX_URL = 'https://piston-meta.mojang.com/v1/packages/e61d8cebcd9d4721421c60cc35960da0e6487117/19.json';
const LOG4J_URL = 'https://piston-data.mojang.com/v1/objects/39384bd14c0606d812afec88d8aff595b2587dd9/client-1.21.2.xml';
const JRE_URL = 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse';
const MOD_URL = 'https://www.dropbox.com/scl/fi/27qh4v5ut9vkpejs3xyan/nebula-visuals-1.0.0.jar?rlkey=arire7jar9q2q1kiydf88pccf&st=5hckmysw&dl=1';
const FAPI_URL = 'https://www.dropbox.com/scl/fi/bleqpiqnbpr09lq00ychs/fabric-api-0.119.4-1.21.4.jar?rlkey=abcsi8ahvd35jdwqff6wjh51r&st=ifwu2y6l&dl=1';
const VOICECHAT_FILE = 'voicechat-fabric-1.21.4-2.6.24.jar';
const VOICECHAT_URL = 'https://cdn.modrinth.com/data/9eGKb6K1/versions/rpQynQWV/voicechat-fabric-1.21.4-2.6.24.jar';
const LOCAL_VOICECHAT = 'D:\\8\\voicechat-fabric-1.21.4-2.6.24.jar';
const LOCAL_MOD = 'E:\\\u0432\u0438\u0437\u0443\u0430\u043b 1.21.4\\Nebula Visuals 1.21.4\\build\\libs\\nebula-visuals-1.0.0.jar';
const BUNDLED_MOD = path.join(__dirname, 'NebulaVisuals.jar');
const MOD_SOURCE = isRealJar(BUNDLED_MOD) ? BUNDLED_MOD : LOCAL_MOD;
const HWID_FILE = 'C:\\NebulaVisuals\\hwid.json';
// ===== Обновление мода 1.21.4 с Dropbox без обновления лаунчера =====
// При старте спрашиваем у Dropbox размер файла; если отличается от локального —
// считаем мод устаревшим и докачиваем его при следующем запуске игры.
let REMOTE_MOD_META = null;
function headRequestFollow(url, depth, timeoutMs) {
return new Promise((resolve) => {
if (depth > 8) return resolve(null);
let req = null;
const timer = setTimeout(() => { try { if (req) req.destroy(); } catch (e) { } resolve(null); }, timeoutMs);
try {
const u = new URL(url);
const lib = u.protocol === 'https:' ? https : http;
req = lib.request({
method: 'HEAD', hostname: u.hostname, path: u.pathname + u.search,
agent: httpsAgent,
headers: { 'User-Agent': 'NebulaVisuals/' + PKG_VERSION + ' (launcher)' }
}, (res) => {
clearTimeout(timer);
const code = res.statusCode;
const loc = res.headers && res.headers.location;
if ([301, 302, 303, 307, 308].indexOf(code) !== -1 && loc) {
try { res.resume(); } catch (e) { }
return headRequestFollow(new URL(loc, url).toString(), depth + 1, timeoutMs).then(resolve);
}
if (code !== 200 && code !== 206) { try { res.resume(); } catch (e) { } return resolve(null); }
const len = parseInt(res.headers['content-length'], 10) || 0;
try { res.resume(); } catch (e) { }
if (len < 1000000) return resolve(null);
resolve({ size: len });
});
req.on('error', () => { clearTimeout(timer); resolve(null); });
req.end();
} catch (e) { clearTimeout(timer); resolve(null); }
});
}
function primeRemoteModMeta() {
return headRequestFollow(MOD_URL, 0, 8000).then((meta) => {
REMOTE_MOD_META = meta;
return meta;
}).catch(() => { REMOTE_MOD_META = null; return null; });
}
primeRemoteModMeta().catch(() => { });
function getMacAddress() {
try {
const ifaces = os.networkInterfaces() || {};
const names = Object.keys(ifaces).sort();
for (const name of names) {
for (const iface of ifaces[name] || []) {
if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
return iface.mac.replace(/:/g, '').toUpperCase();
}
}
}
} catch (e) { }
return 'NOMAC';
}
function generateHwid() {
try {
const cpu = os.cpus() && os.cpus()[0] ? os.cpus()[0].model : 'CPU';
const user = os.userInfo().username || 'user';
const raw = [getMacAddress(), cpu, user, os.platform(), os.arch()].join('|');
return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32).toUpperCase();
} catch (e) {
return crypto.randomBytes(16).toString('hex').toUpperCase();
}
}
function loadHwid() {
try {
const j = JSON.parse(fs.readFileSync(HWID_FILE, 'utf8'));
if (j && j.hwid) return j.hwid;
} catch (e) { }
return null;
}
function saveHwid(hwid) {
try {
ensureDir(path.dirname(HWID_FILE));
fs.writeFileSync(HWID_FILE, JSON.stringify({ hwid: hwid, created: new Date().toISOString() }, null, 2));
} catch (e) { }
}
function getOrCreateHwid() {
const existing = loadHwid();
if (existing) return existing;
const hwid = generateHwid();
saveHwid(hwid);
return hwid;
}
const vanillaLibs = [
'com/fasterxml/jackson/core/jackson-annotations/2.13.4/jackson-annotations-2.13.4.jar',
'com/fasterxml/jackson/core/jackson-core/2.13.4/jackson-core-2.13.4.jar',
'com/fasterxml/jackson/core/jackson-databind/2.13.4.2/jackson-databind-2.13.4.2.jar',
'com/github/oshi/oshi-core/6.6.5/oshi-core-6.6.5.jar',
'com/github/stephenc/jcip/jcip-annotations/1.0-1/jcip-annotations-1.0-1.jar',
'com/google/code/gson/gson/2.11.0/gson-2.11.0.jar',
'com/google/guava/failureaccess/1.0.2/failureaccess-1.0.2.jar',
'com/google/guava/guava/33.3.1-jre/guava-33.3.1-jre.jar',
'com/ibm/icu/icu4j/76.1/icu4j-76.1.jar',
'com/microsoft/azure/msal4j/1.17.2/msal4j-1.17.2.jar',
'com/mojang/authlib/6.0.57/authlib-6.0.57.jar',
'com/mojang/blocklist/1.0.10/blocklist-1.0.10.jar',
'com/mojang/brigadier/1.3.10/brigadier-1.3.10.jar',
'com/mojang/datafixerupper/8.0.16/datafixerupper-8.0.16.jar',
'com/mojang/jtracy/1.0.29/jtracy-1.0.29.jar',
'com/mojang/jtracy/1.0.29/jtracy-1.0.29-natives-windows.jar',
'com/mojang/logging/1.5.10/logging-1.5.10.jar',
'com/mojang/patchy/2.2.10/patchy-2.2.10.jar',
'com/mojang/text2speech/1.17.9/text2speech-1.17.9.jar',
'com/nimbusds/content-type/2.3/content-type-2.3.jar',
'com/nimbusds/lang-tag/1.7/lang-tag-1.7.jar',
'com/nimbusds/nimbus-jose-jwt/9.40/nimbus-jose-jwt-9.40.jar',
'com/nimbusds/oauth2-oidc-sdk/11.18/oauth2-oidc-sdk-11.18.jar',
'commons-codec/commons-codec/1.17.1/commons-codec-1.17.1.jar',
'commons-io/commons-io/2.17.0/commons-io-2.17.0.jar',
'commons-logging/commons-logging/1.3.4/commons-logging-1.3.4.jar',
'io/netty/netty-buffer/4.1.115.Final/netty-buffer-4.1.115.Final.jar',
'io/netty/netty-codec/4.1.115.Final/netty-codec-4.1.115.Final.jar',
'io/netty/netty-common/4.1.115.Final/netty-common-4.1.115.Final.jar',
'io/netty/netty-handler/4.1.115.Final/netty-handler-4.1.115.Final.jar',
'io/netty/netty-resolver/4.1.115.Final/netty-resolver-4.1.115.Final.jar',
'io/netty/netty-transport/4.1.115.Final/netty-transport-4.1.115.Final.jar',
'io/netty/netty-transport-classes-epoll/4.1.115.Final/netty-transport-classes-epoll-4.1.115.Final.jar',
'io/netty/netty-transport-native-unix-common/4.1.115.Final/netty-transport-native-unix-common-4.1.115.Final.jar',
'it/unimi/dsi/fastutil/8.5.15/fastutil-8.5.15.jar',
'net/java/dev/jna/jna/5.15.0/jna-5.15.0.jar',
'net/java/dev/jna/jna-platform/5.15.0/jna-platform-5.15.0.jar',
'net/minidev/accessors-smart/2.5.1/accessors-smart-2.5.1.jar',
'net/minidev/json-smart/2.5.1/json-smart-2.5.1.jar',
'net/sf/jopt-simple/jopt-simple/5.0.4/jopt-simple-5.0.4.jar',
'org/apache/commons/commons-compress/1.27.1/commons-compress-1.27.1.jar',
'org/apache/commons/commons-lang3/3.17.0/commons-lang3-3.17.0.jar',
'org/apache/httpcomponents/httpclient/4.5.14/httpclient-4.5.14.jar',
'org/apache/httpcomponents/httpcore/4.4.16/httpcore-4.4.16.jar',
'org/apache/logging/log4j/log4j-api/2.24.1/log4j-api-2.24.1.jar',
'org/apache/logging/log4j/log4j-core/2.24.1/log4j-core-2.24.1.jar',
'org/apache/logging/log4j/log4j-slf4j2-impl/2.24.1/log4j-slf4j2-impl-2.24.1.jar',
'org/jcraft/jorbis/0.0.17/jorbis-0.0.17.jar',
'org/joml/joml/1.10.8/joml-1.10.8.jar',
'org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3.jar',
'org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-freetype/3.3.3/lwjgl-freetype-3.3.3.jar',
'org/lwjgl/lwjgl-freetype/3.3.3/lwjgl-freetype-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-glfw/3.3.3/lwjgl-glfw-3.3.3.jar',
'org/lwjgl/lwjgl-glfw/3.3.3/lwjgl-glfw-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-jemalloc/3.3.3/lwjgl-jemalloc-3.3.3.jar',
'org/lwjgl/lwjgl-jemalloc/3.3.3/lwjgl-jemalloc-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-openal/3.3.3/lwjgl-openal-3.3.3.jar',
'org/lwjgl/lwjgl-openal/3.3.3/lwjgl-openal-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-opengl/3.3.3/lwjgl-opengl-3.3.3.jar',
'org/lwjgl/lwjgl-opengl/3.3.3/lwjgl-opengl-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-stb/3.3.3/lwjgl-stb-3.3.3.jar',
'org/lwjgl/lwjgl-stb/3.3.3/lwjgl-stb-3.3.3-natives-windows.jar',
'org/lwjgl/lwjgl-tinyfd/3.3.3/lwjgl-tinyfd-3.3.3.jar',
'org/lwjgl/lwjgl-tinyfd/3.3.3/lwjgl-tinyfd-3.3.3-natives-windows.jar',
'org/lz4/lz4-java/1.8.0/lz4-java-1.8.0.jar',
'org/ow2/asm/asm/9.6/asm-9.6.jar',
'org/slf4j/slf4j-api/2.0.16/slf4j-api-2.0.16.jar',
];
const fabricLibs = [
'org/ow2/asm/asm/9.10.1/asm-9.10.1.jar',
'org/ow2/asm/asm-analysis/9.10.1/asm-analysis-9.10.1.jar',
'org/ow2/asm/asm-commons/9.10.1/asm-commons-9.10.1.jar',
'org/ow2/asm/asm-tree/9.10.1/asm-tree-9.10.1.jar',
'org/ow2/asm/asm-util/9.10.1/asm-util-9.10.1.jar',
'net/fabricmc/sponge-mixin/0.17.4+mixin.0.8.7/sponge-mixin-0.17.4+mixin.0.8.7.jar',
'net/fabricmc/intermediary/1.21.4/intermediary-1.21.4.jar',
'net/fabricmc/fabric-loader/0.19.5/fabric-loader-0.19.5.jar',
];
const V1211 = require('./versions-1.21.11.js');
INSTANCE = detectInstance();
const VERSIONS = {
'1.21.4': {
id: '1.21.4',
label: '1.21.4',
badge: '\u0421\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u0430\u044f',
gamePath: GAME_PATH,
gameVersion: '1.21.4',
assetIndexId: '19',
assetIndexUrl: INDEX_URL,
clientUrl: CLIENT_URL,
log4jUrl: LOG4J_URL,
modBundled: 'NebulaVisuals.jar',
modInstalled: 'NebulaVisuals.jar',
modFallback: LOCAL_MOD,
vanillaLibs: vanillaLibs,
fabricLibs: fabricLibs
},
'1.21.11': Object.assign({}, V1211, {
modFallback: null,
modSourceDropbox: MOD_URL
})
};
VERSIONS['1.21.4'].gamePath = instancePath('1.21.4');
VERSIONS['1.21.11'].gamePath = instancePath('1.21.11');
if (VERSIONS['1.21.11'].gameDir) VERSIONS['1.21.11'].gameDir = VERSIONS['1.21.11'].gamePath;
function getVersion(id) {
return VERSIONS[id] || VERSIONS['1.21.4'];
}
function versionList() {
return Object.keys(VERSIONS).map(k => VERSIONS[k]);
}
function isRealFile(p, minSize) {
try {
const st = fs.statSync(p);
return st.isFile() && st.size >= (minSize || 1);
} catch (e) {
return false;
}
}
function isRealJar(p) {
try {
const st = fs.statSync(p);
if (!st.isFile() || st.size < 128) return false;
const fd = fs.openSync(p, 'r');
const buf = Buffer.alloc(2);
fs.readSync(fd, buf, 0, 2, 0);
fs.closeSync(fd);
return buf[0] === 0x50 && buf[1] === 0x4b;
} catch (e) {
return false;
}
}
const httpsAgent = new https.Agent({ keepAlive: true, keepAliveMsecs: 20000, maxSockets: 48 });
const httpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 20000, maxSockets: 48 });
const knownDirs = new Set();
function ensureDirFast(dir) {
if (knownDirs.has(dir)) return;
ensureDir(dir);
knownDirs.add(dir);
}
function httpDownload(url, dest, onProgress) {
return new Promise((resolve, reject) => {
ensureDirFast(path.dirname(dest));
const tmp = dest + '.tmp';
try { fs.unlinkSync(tmp); } catch (e) { }
let settled = false;
const out = fs.createWriteStream(tmp);
const fail = (err) => {
if (settled) return;
settled = true;
try { out.destroy(); } catch (e) { }
try { fs.unlinkSync(tmp); } catch (e) { }
reject(err);
};
const go = (currentUrl, depth) => {
if (depth > 8) return fail(new Error('\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u043d\u043e\u0433\u043e \u043f\u0435\u0440\u0435\u043d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0439'));
const lib = currentUrl.startsWith('https:') ? https : http;
let req;
try {
req = lib.get(currentUrl, {
agent: currentUrl.startsWith('https:') ? httpsAgent : httpAgent,
headers: {
'User-Agent': 'NebulaVisuals/' + PKG_VERSION,
'Accept': '*/*'
}
}, (res) => {
if ([301, 302, 303, 307, 308].indexOf(res.statusCode) !== -1 && res.headers.location) {
res.resume();
return go(new URL(res.headers.location, currentUrl).toString(), depth + 1);
}
if (res.statusCode !== 200) {
res.resume();
return fail(new Error('HTTP ' + res.statusCode));
}
res.on('error', fail);
const progTotal = parseInt(res.headers['content-length'], 10) || 0;
let progReceived = 0;
if (onProgress) {
res.on('data', (chunk) => {
progReceived += chunk.length;
try { onProgress(progReceived, progTotal); } catch (e) { }
});
}
res.pipe(out);
out.on('finish', () => {
if (settled) return;
out.close(() => {
if (settled) return;
settled = true;
try {
fs.renameSync(tmp, dest);
resolve();
} catch (e) {
reject(e);
}
});
});
});
} catch (e) {
return fail(e);
}
req.on('error', fail);
req.setTimeout(90000, () => req.destroy(new Error('\u0422\u0430\u0439\u043c\u0430\u0443\u0442 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438')));
};
go(url, 0);
});
}
async function downloadRetry(url, dest, attempts, onProgress) {
let lastErr;
const tries = attempts || 3;
for (let i = 0; i < tries; i++) {
try {
await httpDownload(url, dest, onProgress);
return;
} catch (e) {
lastErr = e;
await new Promise(r => setTimeout(r, 800 * (i + 1)));
}
}
throw lastErr;
}

// ===== Быстрая локальная проверка файлов при входе =====
// Только чтение: ничего не качается и не меняется. Если файлы на месте —
// моментально входим в главное меню. Если чего-то нет или клиент устарел —
// просто запоминаем: файлы докачиваются кнопкой «Запустить» как раньше,
// а надпись «Новое обновление!» показывается до установки нового клиента.
let verifyAllRunning = false;
function clientModUpdateAvailable() {
  for (const v of versionList()) {
    const GP = v.gamePath;
    if (!fs.existsSync(path.join(GP, 'libraries'))) continue; // бета без файлов — «обновления» не показываем
    const vv = Object.assign({}, v, { gamePath: GP });
    const clientMod = path.join(GP, 'mods', vv.modInstalled || 'NebulaVisuals.jar');
    if (!isRealJar(clientMod)) continue; // отсутствие — это не «обновление»
    if (clientModOutdated(vv)) return true;
  }
  return false;
}
async function verifyAllAtLogin() {
  if (verifyAllRunning) return;
  verifyAllRunning = true;
  try {
    const targets = versionList().filter(v => v.id !== '1.21.11' || fs.existsSync(path.join(v.gamePath, 'libraries')));
    const total = Math.max(1, targets.length);
    const t0 = Date.now();
    let step = 0;
    for (const v of targets) {
      const GP = v.gamePath;
      const vv = Object.assign({}, v, { gamePath: GP });
      const base = (step / total) * 100;
      const span = 100 / total;
      let localPct = 5;
      const tick = (msg) => {
        localPct = Math.min(95, localPct + 13);
        if (win) try { win.webContents.send('verify:progress', { percent: Math.round(base + (span * localPct) / 100), sub: String(msg) }); } catch (e) { }
      };
      try {
        checkFilesDetailed(tick, vv);
      } catch (e) {
        console.error('verify scan failed', e);
      }
      if (win) try { win.webContents.send('verify:progress', { percent: Math.round(base + span), sub: 'Проверка файлов...' }); } catch (e) { }
      step++;
    }
    // не мигаем экраном проверки — держим его хотя бы пару секунд
    const spent = Date.now() - t0;
    if (spent < 2000) {
      const remain = 2000 - spent;
      if (win) try { win.webContents.send('verify:progress', { percent: 100, sub: 'Всё актуально' }); } catch (e) { }
      await new Promise(r => setTimeout(r, remain));
    }
    if (clientModUpdateAvailable() && win) {
      try { win.webContents.send('mods:update-found'); } catch (e) { }
    }
    if (win) try { win.webContents.send('verify:progress', { percent: 100, sub: 'Всё актуально' }); } catch (e) { }
    if (win) try { win.webContents.send('verify:done', { updated: 0 }); } catch (e) { }
  } catch (err) {
    const message = String((err && err.message) || err);
    console.error('verify failed', err);
    if (win) try { win.webContents.send('verify:failed', { message: message }); } catch (e) { }
  } finally {
    verifyAllRunning = false;
  }
}
ipcMain.on('mods:check-updates', () => { verifyAllAtLogin().catch(e => console.error('verify failed', e)); });

// Информация о системе — для автоподбора ОЗУ в настройках
ipcMain.handle('sys:info', () => {
try {
const totalMB = Math.floor(os.totalmem() / (1024 * 1024));
const freeMB = Math.floor(os.freemem() / (1024 * 1024));
const cpus = (os.cpus() || []).length;
return { totalMB: totalMB, freeMB: freeMB, cpus: cpus };
} catch (e) {
return { totalMB: 0, freeMB: 0, cpus: 1 };
}
});

// ===== Кнопка «Слабый ПК» — оптимизация в один клик =====
// Выставляет рекомендуемое ОЗУ по объёму системы и докачивает нужные
// оптимизационные моды (Sodium/Lithium/FerriteCore/EntityCulling/
// ImmediatelyFast/ModernFix) под выбранную версию, заменяя их старые версии.
const WEAK_MODS = [
{ slug: 'sodium',          name: 'Sodium',          match: ['sodium'] },
{ slug: 'lithium',         name: 'Lithium',         match: ['lithium'] },
{ slug: 'ferrite-core',    name: 'FerriteCore',     match: ['ferrite'] },
{ slug: 'entityculling',   name: 'EntityCulling',   match: ['entityculling', 'entity-culling'] },
{ slug: 'immediatelyfast', name: 'ImmediatelyFast', match: ['immediatelyfast', 'immediately-fast'] },
{ slug: 'badoptimizations', name: 'BadOptimizations', match: ['badoptimizations', 'bad-optimizations'] },
{ slug: 'c2me-fabric',     name: 'C2ME (Chunk engine)', match: ['c2me'] },
{ slug: 'krypton',         name: 'Krypton',         match: ['krypton'] },
{ slug: 'sodium-extra',    name: 'Sodium Extra',    match: ['sodium-extra', 'sodium_extra'] },
{ slug: 'dynamic-fps',     name: 'Dynamic FPS',     match: ['dynamic-fps', 'dynamic_fps'] }
];
function weakRamRecommendationMB(totalBytes) {
const step = 512 * 1024 * 1024;
const half = Math.floor(totalBytes / 2 / step) * 512;
const gb = totalBytes / (1024 * 1024 * 1024);
if (gb <= 4) return 3072;
if (gb <= 8) return 4096;
if (gb <= 12) return 5120;
return Math.min(32768, half);
}
function jarMatchesName(filename, matchList) {
const f = String(filename).toLowerCase();
for (const s of matchList) { if (f.includes(s)) return true; }
return false;
}
ipcMain.handle('weakpc:apply', async (event, payload) => {
const send = (msg) => { try { event.sender.send('weakpc:progress', msg); } catch (e) { } };
try {
const versionId = String((payload && payload.version) || '1.21.4');
const v = getVersion(versionId);
const GP = v.gamePath;
const modsDir = path.join(GP, 'mods');
ensureDir(modsDir);
const totalRam = os.totalmem();
const recRam = weakRamRecommendationMB(totalRam);
const totalGb = Math.round((totalRam / (1024 * 1024 * 1024)) * 10) / 10;
send({ stage: 'ram', ram: recRam, totalGb: totalGb });
const downloaded = [], failed = [];
let idx = 0;
for (const mod of WEAK_MODS) {
idx++;
send({ stage: 'progress', done: idx, total: WEAK_MODS.length, name: mod.name });
// убираем старые версии этого же мода
try {
fs.readdirSync(modsDir)
.filter(f => f.toLowerCase().endsWith('.jar') && jarMatchesName(f, mod.match))
.forEach(f => { try { fs.unlinkSync(path.join(modsDir, f)); } catch (e) { } });
} catch (e) { }
// свежая сборка с Modrinth под Fabric + нужную версию
const gv = encodeURIComponent(JSON.stringify([v.gameVersion]));
const url = MODRINTH_API + '/project/' + encodeURIComponent(mod.slug) +
'/version?loaders=%5B%22fabric%22%5D&game_versions=' + gv;
const res = await modrinthGet(url);
if (!res.ok || !Array.isArray(res.json) || res.json.length === 0) {
failed.push(mod.name + ': ' + ((res && res.error) || ('не найден под ' + v.gameVersion)));
continue;
}
const versions = res.json.slice().sort((a, b) => String(b.date_created || '').localeCompare(String(a.date_created || '')));
let chosen = null;
for (const ver of versions) {
const files = Array.isArray(ver.files) ? ver.files : [];
const file = files.find(f => f.primary) || files[0];
if (file && file.url && file.filename) { chosen = file; break; }
}
if (!chosen) { failed.push(mod.name + ': нет файла'); continue; }
const dest = path.join(modsDir, chosen.filename);
try {
await downloadRetry(chosen.url, dest, 3);
if (isRealJar(dest)) downloaded.push(mod.name);
else failed.push(mod.name + ': битый файл');
} catch (e) {
failed.push(mod.name + ': ошибка загрузки');
}
}
return { ok: failed.length === 0, downloaded: downloaded, failed: failed, ram: recRam, totalGb: totalGb, version: v.id };
} catch (e) {
console.error('weakpc error', e);
return { ok: false, error: String((e && e.message) || e) };
}
});

// ===== Самообновление лаунчера =====
// При входе лаунчер проверяет манифест на сайте. Если вышла новее версия,
// скачивает небольшой zip только с изменёнными файлами, распаковывает прямо в
// папку лаунчера и перезапускается сам (установщик не нужен). Новый zip со всем
// проектом стоит ~5–10 КБ против ~300 МБ полного инсталлера.
const LAUNCHER_UPDATE_MANIFEST = 'https://nebulavisuals-public.vercel.app/files/launcher-update.json';
function semverToNum(v) {
const m = /^(\d+)\.(\d+)\.(\d+)/.exec(String(v || '').trim());
if (!m) return 0;
return Number(m[1]) * 10000 + Number(m[2]) * 100 + Number(m[3]);
}
ipcMain.handle('app:get-version', () => PKG_VERSION);
ipcMain.handle('app:check-launcher-update', async () => {
try {
const url = LAUNCHER_UPDATE_MANIFEST + '?v=' + Date.now();
const r = await httpsGetJson(url);
if (!r.ok || !r.json) return { ok: false, error: 'Не удалось проверить обновление' };
const remoteVersion = String(r.json.version || '');
if (semverToNum(remoteVersion) > semverToNum(PKG_VERSION)) {
return { ok: true, update: true, to: remoteVersion };
}
return { ok: true, update: false, to: remoteVersion };
} catch (e) {
return { ok: false, error: 'Не удалось проверить обновление' };
}
});
ipcMain.handle('app:apply-launcher-update', async (event) => {
try {
const r = await httpsGetJson(LAUNCHER_UPDATE_MANIFEST + '?v=' + Date.now());
if (!r.ok || !r.json) return { ok: false, error: 'Не удалось получить манифест обновления' };
const m = r.json;
const remoteVersion = String(m.version || '');
if (semverToNum(remoteVersion) <= semverToNum(PKG_VERSION)) return { ok: true, update: false };
if (!m.url) return { ok: false, error: 'В манифесте нет ссылки на обновление' };
const fileName = String(m.name || 'launcher-patch.zip');
const tmpZip = path.join(os.tmpdir(), fileName);
try { fs.unlinkSync(tmpZip); } catch (e) { }
await downloadRetry(m.url, tmpZip, 3, (received, total) => {
try { event.sender.send('update:progress', { percent: total > 0 ? Math.min(99, Math.round(received / total * 100)) : 0, received, total }); } catch (e) { }
});
const st = fs.statSync(tmpZip);
const expected = Number(m.size || 0);
if (expected > 0 && st.size !== expected) {
try { fs.unlinkSync(tmpZip); } catch (e) { }
return { ok: false, error: 'Скачанное обновление повреждено (размер не совпадает)' };
}
// SHA-256 — защита от подмены файла
if (m.sha256) {
const computed = crypto.createHash('sha256').update(fs.readFileSync(tmpZip)).digest('hex');
if (computed.toLowerCase() !== String(m.sha256).toLowerCase()) {
try { fs.unlinkSync(tmpZip); } catch (e) { }
return { ok: false, error: 'Скачанное обновление повреждено (подпись не совпала)' };
}
}
// Распаковываем zip прямо в папку лаунчера (asar отключён — файлы реальны)
const appDir = __dirname;
const extractDir = path.join(os.tmpdir(), 'nebula-update-staging');
try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (e) { }
try { fs.mkdirSync(extractDir); } catch (e) { }
try {
await runHidden('tar.exe', ['-xf', tmpZip, '-C', extractDir], extractDir);
} catch (e) {
try { fs.unlinkSync(tmpZip); } catch (e2) { }
return { ok: false, error: 'Не удалось распаковать обновление' };
}
try {
const copyIntoDir = (src, dst) => {
for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
const s = path.join(src, entry.name);
const d = path.join(dst, entry.name);
if (entry.isDirectory()) {
fs.mkdirSync(d, { recursive: true });
copyIntoDir(s, d);
} else {
fs.copyFileSync(s, d);
}
}
};
copyIntoDir(extractDir, appDir);
} catch (e) {
try { fs.unlinkSync(tmpZip); } catch (e3) { }
return { ok: false, error: 'Не удалось применить обновление: ' + String((e && e.message) || e) };
}
try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (e) { }
try { fs.unlinkSync(tmpZip); } catch (e) { }
try { event.sender.send('update:progress', { percent: 100 }); } catch (e) { }
// Перезапускаем лаунчер уже с новой версией (сначала даём экрану обновления докрутиться)
setTimeout(() => { try { app.relaunch(); app.exit(0); } catch (e) { } }, 10500);
return { ok: true, update: true, from: PKG_VERSION, to: m.version };
} catch (e) {
return { ok: false, error: 'Не удалось установить обновление: ' + String((e && e.message) || e) };
}
});




function runHidden(file, args, cwd) {
return new Promise((resolve, reject) => {
const p = spawn(file, args, { windowsHide: true, cwd: cwd });
let out = '';
let err = '';
if (p.stdout) p.stdout.on('data', d => { out += d.toString(); });
if (p.stderr) p.stderr.on('data', d => { err += d.toString(); });
p.on('error', reject);
p.on('close', (code) => {
if (code === 0) resolve(out + err);
else reject(new Error((err || out || '').trim() || ('\u043a\u043e\u0434 ' + code)));
});
});
}
function allInstalled() {
const GPI = getVersion('1.21.4').gamePath;
const libDir = path.join(GPI, 'libraries');
for (const lib of vanillaLibs) {
if (!isRealJar(path.join(libDir, path.basename(lib)))) return false;
}
for (const lib of fabricLibs) {
if (!isRealJar(path.join(libDir, path.basename(lib)))) return false;
}
if (!isRealJar(path.join(libDir, 'client.jar'))) return false;
if (!isRealJar(path.join(GPI, 'mods', 'NebulaVisuals.jar'))) return false;
if (!isRealJar(path.join(GPI, 'mods', 'fabric-api.jar'))) return false;
if (!isRealJar(path.join(GPI, 'mods', VOICECHAT_FILE))) return false;
if (!isRealFile(path.join(GPI, 'assets', 'indexes', '19.json'), 1024)) return false;
if (!isRealFile(path.join(GPI, 'assets', 'log4j2.xml'), 128)) return false;
if (!isRealFile(path.join(GPI, 'assets', '.ok'))) return false;
if (!isRealFile(path.join(GPI, 'natives', '.ok'))) return false;
if (!isRealFile(path.join(GPI, 'natives', 'lwjgl.dll'), 1024)) return false;
const hasJava = isRealFile(path.join(GPI, 'java', 'bin', 'java.exe'), 1024)
|| isRealFile(path.join(GPI, 'java', 'bin', 'javaw.exe'), 1024);
if (!hasJava) return false;
return true;
}
const USER_FOLDERS = ['themes', 'configs', 'profile'];
function folderExists(name, gamePath) {
try {
return fs.statSync(path.join(gamePath || GAME_PATH, name)).isDirectory();
} catch (e) {
return false;
}
}
function modSourceFor(version) {
const bundled = path.join(__dirname, version.modBundled || 'NebulaVisuals.jar');
if (isRealJar(bundled)) return bundled;
if (version.modFallback && isRealJar(version.modFallback)) return version.modFallback;
return null;
}
function clientModOutdated(version) {
const v = version || getVersion('1.21.4');
const installed = path.join(v.gamePath, 'mods', v.modInstalled || 'NebulaVisuals.jar');
if (!isRealJar(installed)) return true;
const src = modSourceFor(v);
let localOutdated = false;
if (src) {
try {
const a = fs.statSync(installed);
const b = fs.statSync(src);
if (b.size !== a.size) {
localOutdated = true;
} else {
const ha = crypto.createHash('md5').update(fs.readFileSync(installed)).digest('hex');
const hb = crypto.createHash('md5').update(fs.readFileSync(src)).digest('hex');
localOutdated = ha !== hb;
}
} catch (e) {
localOutdated = false;
}
}
// Если установлен ровно тот файл, что на Dropbox — это актуальная сборка
try {
if (REMOTE_MOD_META && REMOTE_MOD_META.size) {
const a = fs.statSync(installed);
if (a.size === REMOTE_MOD_META.size) return false;
}
} catch (e) { }
if (localOutdated) return true;
// Иначе сверяем с удалённым файлом: изменился — значит, нужно обновление
try {
if (REMOTE_MOD_META && REMOTE_MOD_META.size) {
const a = fs.statSync(installed);
if (a.size !== REMOTE_MOD_META.size) return true;
}
} catch (e) { }
return false;
}
const assetIndexCache = {};
function readAssetIndex(GP, v) {
const key = GP + '|' + v.assetIndexId;
if (assetIndexCache[key]) return assetIndexCache[key];
let idx = null;
try {
idx = JSON.parse(fs.readFileSync(path.join(GP, 'assets', 'indexes', v.assetIndexId + '.json'), 'utf8'));
} catch (e) { idx = null; }
assetIndexCache[key] = idx;
return idx;
}
function assetsComplete(gamePath, version) {
const GP = gamePath || GAME_PATH;
const v = version || getVersion('1.21.4');
const marker = path.join(GP, 'assets', '.ok');
try {
const raw = fs.readFileSync(marker, 'utf8').trim();
const stored = parseInt(raw, 10) || 0;
if (stored <= 0) return false;
const idx = readAssetIndex(GP, v);
const hashes = [];
const objects = (idx && idx.objects) || {};
const seen = new Set();
for (const k of Object.keys(objects)) {
const h = objects[k] && objects[k].hash;
if (!h || seen.has(h)) continue;
seen.add(h);
hashes.push(h);
}
if (stored < hashes.length) return false;
const sample = hashes.slice(0, 40);
for (const h of sample) {
if (!isRealFile(path.join(GP, 'assets', 'objects', h.substring(0, 2), h), 1)) return false;
}
return true;
} catch (e) {
return false;
}
}
function checkFilesDetailed(sendStatus, version) {
const v = version || getVersion('1.21.4');
const GP = v.gamePath;
const libDir = path.join(GP, 'libraries');
let missing = false;
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: \u0431\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a\u0438...');
for (const lib of v.vanillaLibs) {
if (!isRealJar(path.join(libDir, path.basename(lib)))) missing = true;
}
for (const lib of v.fabricLibs) {
if (!isRealJar(path.join(libDir, path.basename(lib)))) missing = true;
}
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: client.jar...');
if (!isRealJar(path.join(libDir, 'client.jar'))) missing = true;
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0435 \u0431\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a\u0438...');
if (!isRealFile(path.join(GP, 'natives', '.ok'))) missing = true;
if (!isRealFile(path.join(GP, 'natives', 'lwjgl.dll'), 1024)) missing = true;
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: \u043c\u043e\u0434\u044b...');
if (!isRealJar(path.join(GP, 'mods', 'fabric-api.jar'))) missing = true;
if (!isRealJar(path.join(GP, 'mods', VOICECHAT_FILE))) missing = true;
let update = false;
const clientMod = path.join(GP, 'mods', v.modInstalled || 'NebulaVisuals.jar');
if (!isRealJar(clientMod)) {
missing = true;
} else if (clientModOutdated(v)) {
update = true;
}
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: \u0440\u0435\u0441\u0443\u0440\u0441\u044b \u0438\u0433\u0440\u044b...');
if (!isRealFile(path.join(GP, 'assets', 'indexes', v.assetIndexId + '.json'), 1024)) missing = true;
if (!isRealFile(path.join(GP, 'assets', 'log4j2.xml'), 128)) missing = true;
if (!assetsComplete(GP, v)) missing = true;
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: \u043f\u0430\u043f\u043a\u0438 themes, configs, profile...');
for (const f of USER_FOLDERS) {
if (!folderExists(f, GP)) missing = true;
}
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0444\u0430\u0439\u043b\u043e\u0432: Java 21...');
const hasJava = isRealFile(path.join(GP, 'java', 'bin', 'java.exe'), 1024)
|| isRealFile(path.join(GP, 'java', 'bin', 'javaw.exe'), 1024);
if (!hasJava) missing = true;
return { ok: !missing && !update, update: update, missing: missing };
}
const PROTECTED_GAME_DIRS = [
'config', 'configs', 'profile', 'profiles', 'themes', 'servers',
'resourcepacks', 'saves', 'worlds', 'shaderpacks', 'screenshots', 'logs', 'crash-reports'
];
function isProtectedGamePath(p) {
if (!p) return false;
const norm = String(p).replace(/\\/g, '/').toLowerCase();
for (let i = 0; i < PROTECTED_GAME_DIRS.length; i++) {
const d = PROTECTED_GAME_DIRS[i];
if (norm.indexOf('/' + d + '/') !== -1 || norm.endsWith('/' + d)) return true;
}
return false;
}
function cleanupStaleFiles(version) {
if (typeof INSTANCE !== 'undefined' && INSTANCE > 1) return;
const v = version || getVersion('1.21.4');
const GP = v.gamePath;
const libsDir = path.join(GP, 'libraries');
if (fs.existsSync(libsDir)) {
let names = [];
try { names = fs.readdirSync(libsDir); } catch (e) { names = []; }
for (const name of names) {
const low = name.toLowerCase();
const full = path.join(libsDir, name);
if (!low.endsWith('.jar')) continue;
const knownBad = low.indexOf('netty-all-') === 0
|| low.indexOf('netty-transport-native-epoll-') === 0
|| low.indexOf('netty-transport-native-kqueue-') === 0
|| low.indexOf('lwjgl-all-') === 0
|| low.indexOf('logging-all-') === 0
|| (low.indexOf('netty-') === 0 && low.indexOf('4.1.115.final') === -1);
const broken = !isRealJar(full);
if (isProtectedGamePath(full)) continue;
if (knownBad || broken) {
try { fs.unlinkSync(full); } catch (e) { }
}
}
}
const modsDir = path.join(GP, 'mods');
if (fs.existsSync(modsDir)) {
let names = [];
try { names = fs.readdirSync(modsDir); } catch (e) { names = []; }
const staleMods = /^(nebula-visuals-.*|fabric-api-[\d.].*|client-1\.21.*)\.jar$/i;
for (const name of names) {
if (!name.toLowerCase().endsWith('.jar')) continue;
if (name === (v.modInstalled || 'NebulaVisuals.jar') || name === 'fabric-api.jar' || name === VOICECHAT_FILE) continue;
const full = path.join(modsDir, name);
const isOldVoicechat = /^voicechat-fabric-.*\.jar$/i.test(name);
if (isProtectedGamePath(full)) continue;
if (staleMods.test(name) || isOldVoicechat || !isRealJar(full)) {
try { fs.unlinkSync(full); } catch (e) { }
}
}
}
}
async function runPool(items, limit, worker) {
let index = 0;
const runners = [];
const count = Math.min(limit, items.length);
for (let i = 0; i < count; i++) {
runners.push((async () => {
while (index < items.length) {
const current = items[index++];
await worker(current);
}
})());
}
await Promise.all(runners);
}
function readLogTail(lines, gamePath) {
try {
const base = gamePath || instancePath('1.21.4');
const content = fs.readFileSync(path.join(base, 'game.log'), 'utf8');
const arr = content.split(/\r?\n/).filter(l => l.trim().length > 0);
return arr.slice(-(lines || 20)).join('\n');
} catch (e) {
return '';
}
}
async function findSystemJava() {
const candidates = [];
for (const exe of ['java.exe', 'javaw.exe']) {
try {
const whereOut = await runHidden('where.exe', [exe]);
for (const line of whereOut.split(/\r?\n/)) {
const p = line.trim();
if (p && new RegExp(exe.replace('.', '\\.') + '$', 'i').test(p)) candidates.push(p);
}
} catch (e) { }
}
if (process.env.JAVA_HOME) {
candidates.push(path.join(process.env.JAVA_HOME, 'bin', 'java.exe'));
candidates.push(path.join(process.env.JAVA_HOME, 'bin', 'javaw.exe'));
}
for (const candidate of candidates) {
if (!isRealFile(candidate, 1024)) continue;
try {
const javaExe = candidate.replace(/javaw\.exe$/i, 'java.exe');
const ver = await runHidden(javaExe, ['-version']);
const m = ver.match(/version\s+"(?:1\.)?(\d+)/i);
if (m && parseInt(m[1], 10) >= 21) return javaExe;
} catch (e) { }
}
return null;
}
let launchInProgress = false;
const MC_OPTIONS = {
fov: '0.0',
gamma: '1.0',
renderDistance: '12',
simulationDistance: '12',
guiScale: '2',
maxFps: '260',
particles: '2',
ao: 'true',
entityShadows: 'true',
enableVsync: 'false',
bobView: 'false',
toggleCrouch: 'false',
autoJump: 'true',
sprintKey: 'false',
invertYMouse: 'false',
touchscreen: 'false',
chatOpacity: '1.0',
darkMojangStudiosBackground: 'false',
pauseOnLostFocus: 'false',
fullscreen: 'false',
narrator: '0',
soundCategory_master: '0.0',
tutorialStep: 'none',
skipMultiplayerWarning: 'true',
onboardAccessibility: 'false',
hideBundleTutorial: 'true',
highlighters: 'true',
fovEffectScale: '0.0',
screenEffectScale: '1.0',
glintSpeed: '0.0',
glintStrength: '0.0',
damageTiltStrength: '0.0',
toggleCrouch: 'false',
autoJump: 'true',
attackIndicator: '1',
darkMojangStudiosBackground: 'false'
};
function writeMinecraftOptions(gamePath) {
try {
const dir = gamePath;
ensureDir(dir);
const file = path.join(dir, 'options.txt');
let current = '';
try { current = fs.readFileSync(file, 'utf8'); } catch (e) { current = ''; }
const map = {};
current.split('\n').forEach(function (line) {
const i = line.indexOf(':');
if (i > 0) map[line.slice(0, i).trim()] = line.slice(i + 1).trim();
});
Object.keys(MC_OPTIONS).forEach(function (k) {
map[k] = MC_OPTIONS[k];
});
const out = Object.keys(map).map(function (k) { return k + ':' + map[k]; }).join('\n') + '\n';
fs.writeFileSync(file, out, 'utf8');
return true;
} catch (e) {
console.error('options.txt error:', e && e.message ? e.message : e);
return false;
}
}
function sendIngamePing(nick, gameVersion) {
try {
const payload = JSON.stringify({ n: nick, v: gameVersion, ts: Date.now() });
const req = https.request({
hostname: 'ntfy.sh',
path: '/nebula-visuals-ingame-v1',
method: 'POST',
timeout: 8000,
headers: {
'Content-Type': 'application/json',
'Title': 'Nebula in-game',
'Tags': 'video_game'
}
}, () => { });
req.on('error', () => { });
req.on('timeout', () => { try { req.destroy(); } catch (e) { } });
req.write(payload);
req.end();
} catch (e) { }
}
function startIngamePresence(nick, gameVersion, child) {
sendIngamePing(nick, gameVersion);
const iv = setInterval(() => sendIngamePing(nick, gameVersion), 60000);
const stop = () => { try { clearInterval(iv); } catch (e) { } };
try { child.once('exit', stop); child.once('error', stop); } catch (e) { stop(); }
setTimeout(stop, 12 * 60 * 60 * 1000);
}
async function startGame(javaExe, safeUser, safeRam, uuid, sendStatus, version) {
const v = version || getVersion('1.21.4');
const GP = v.gamePath;
const nativesDir = path.join(GP, 'natives');
const classpath = v.fabricLibs.concat(['client.jar'], v.vanillaLibs.filter(l => l.indexOf('asm/9.6/') === -1))
.map(rel => path.join(GP, 'libraries', path.basename(rel)))
.join(';');
const logPath = path.join(GP, 'game.log');
const logFd = fs.openSync(logPath, 'w');
const jvmArgs = [
'-Xmx' + safeRam + 'M',
'-XX:+UseG1GC',
'-XX:MaxGCPauseMillis=50',
'-XX:+UseStringDeduplication',
'-XX:+ParallelRefProcEnabled',
'-XX:+ExplicitGCInvokesConcurrent',
'-XX:HeapDumpPath=' + path.join(GP, 'minecraft.heapdump'),
'-Djava.library.path=' + nativesDir,
'-Djna.tmpdir=' + nativesDir,
'-Dorg.lwjgl.system.SharedLibraryExtractPath=' + nativesDir,
'-Dio.netty.native.workdir=' + nativesDir,
'-Dminecraft.launcher.brand=NebulaVisuals',
'-Dminecraft.launcher.version=' + PKG_VERSION,
'-Dlog4j.configurationFile=' + path.join(GP, 'assets', 'log4j2.xml'),
'-DFabricMcEmu= net.minecraft.client.main.Main ',
'-cp',
classpath,
'net.fabricmc.loader.impl.launch.knot.KnotClient',
'--username', safeUser,
'--version', v.gameVersion,
'--gameDir', GP,
'--assetsDir', path.join(GP, 'assets'),
'--assetIndex', v.assetIndexId,
'--uuid', uuid,
'--accessToken', '0',
'--clientId', '0',
'--xuid', '0',
'--userType', 'legacy',
'--versionType', 'release'
];
sendStatus('\u0417\u0430\u043f\u0443\u0441\u043a Minecraft ' + v.gameVersion + '...');
try { writeMinecraftOptions(GP); } catch (e) { }
try { getOrCreateHwid(); } catch (e) { }
if (SELFTEST_NO_LAUNCH) {
sendStatus('\u0421\u0435\u043b\u0444\u0442\u0435\u0441\u0442: \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0430, \u0437\u0430\u043f\u0443\u0441\u043a \u043f\u0440\u043e\u043f\u0443\u0449\u0435\u043d');
return;
}
const child = spawn(javaExe, jvmArgs, {
cwd: GP,
detached: true,
windowsHide: true,
stdio: ['ignore', logFd, logFd]
});
child.unref();
try { markGameRunning(v.launchSlot || INSTANCE, child.pid); } catch (e) { }
try { fs.closeSync(logFd); } catch (e) { }
const earlyExit = await new Promise((resolve) => {
let settled = false;
child.once('error', (err) => {
if (!settled) { settled = true; resolve('error:' + err.message); }
});
child.once('exit', (code) => {
if (!settled) { settled = true; resolve(code); }
});
setTimeout(() => {
if (!settled) { settled = true; resolve(null); }
}, 4000);
});
if (earlyExit !== null && earlyExit !== 0 && earlyExit !== '0') {
try { markGameRunning(v.launchSlot || INSTANCE, 0); } catch (e) { }
const tail = readLogTail(25, GP);
const detail = tail ? tail.split(/\r?\n/).slice(-4).join(' | ').substring(0, 220) : '';
throw new Error('\u0418\u0433\u0440\u0430 \u0437\u0430\u043a\u0440\u044b\u043b\u0430\u0441\u044c \u043f\u0440\u0438 \u0437\u0430\u043f\u0443\u0441\u043a\u0435. ' + (detail || '\u041f\u043e\u0434\u0440\u043e\u0431\u043d\u043e\u0441\u0442\u0438 \u0432 game.log'));
}
try { startIngamePresence(safeUser, v.gameVersion, child); } catch (e) { }
sendStatus('Minecraft ' + v.gameVersion + ' \u0437\u0430\u043f\u0443\u0449\u0435\u043d' + (INSTANCE > 1 ? ' (\u043e\u043a\u043d\u043e #' + INSTANCE + ')' : ''));
}
async function ensureJava(GP, sendStatus) {
let javaExe = path.join(GP, 'java', 'bin', 'java.exe');
if (!isRealFile(javaExe, 1024)) {
javaExe = path.join(GP, 'java', 'bin', 'javaw.exe');
}
if (!isRealFile(javaExe, 1024)) {
sendStatus('Подготовка Java 21...');
const zipPath = path.join(GP, 'java21.zip');
try {
if (!isRealFile(zipPath, 1000000)) {
await downloadRetry(JRE_URL, zipPath, 2, (received, total) => {
const p = total > 0 ? Math.round((received / total) * 100) : 0;
sendStatus('Скачивание Java 21... ' + p + '%');
});
}
// распаковка через встроенный tar.exe (в разы быстрее PowerShell Expand-Archive)
sendStatus('Распаковка Java 21...');
const extracted = path.join(GP, 'jre_tmp');
try { fs.rmSync(extracted, { recursive: true, force: true }); } catch (e) { }
let ok = false;
try {
await runHidden('tar.exe', ['-xf', 'java21.zip', '-C', 'jre_tmp'], GP);
ok = true;
} catch (e) { ok = false; }
if (!ok) {
// запасной вариант: 7za из ресурсов установщика (если есть)
const zaCandidates = [
process.resourcesPath ? path.join(process.resourcesPath, 'bin', '7za.exe') : null,
process.resourcesPath ? path.join(process.resourcesPath, '7za.exe') : null,
__dirname ? path.join(__dirname, '7za.exe') : null,
path.join(GP, '7za.exe')
].filter(Boolean);
for (const za of zaCandidates) {
try {
if (fs.existsSync(za)) {
await runHidden(za, ['x', '-y', '-ojre_tmp', 'java21.zip'], GP);
ok = true;
break;
}
} catch (e) { /* пробуем следующий кандидат */ }
}
}
if (!ok) {
// последний фолбэк — медленный PowerShell как раньше
const psJre = [
"$ErrorActionPreference = 'Stop'",
"if (Test-Path 'jre_tmp') { Remove-Item 'jre_tmp' -Recurse -Force }",
"Expand-Archive -LiteralPath 'java21.zip' -DestinationPath 'jre_tmp' -Force"
].join('\n');
await runHidden('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psJre], GP);
}
// переносим единственную папку внутри jre_tmp в java
const inner = fs.existsSync(extracted) ? fs.readdirSync(extracted) : [];
if (inner.length === 1) {
const srcDir = path.join(extracted, inner[0]);
if (fs.existsSync(srcDir) && fs.statSync(srcDir).isDirectory()) {
try { fs.rmSync(path.join(GP, 'java'), { recursive: true, force: true }); } catch (e) { }
fs.renameSync(srcDir, path.join(GP, 'java'));
}
}
try { fs.rmSync(extracted, { recursive: true, force: true }); } catch (e) { }
try { fs.rmSync(zipPath, { force: true }); } catch (e) { }
} catch (e) { }
}
if (!isRealFile(javaExe, 1024)) {
sendStatus('Поиск установленной Java 21...');
javaExe = await findSystemJava();
}
if (!javaExe) {
throw new Error('Java 21 не найдена. Установите Java 21 (Adoptium Temurin) и попробуйте снова.');
}
return javaExe;
}


async function ensureGameFiles(GP, vv, sendStatus, onProgress) {
const reportPct = (p, msg) => { if (onProgress) { try { onProgress(Math.max(0, Math.min(100, Math.round(p))), String(msg)); } catch (e) { } } };
let modsTouched = 0;
const dirs = ['libraries', 'mods', 'natives', 'assets', 'assets\\indexes', 'assets\\objects', 'servers', 'resourcepacks', 'config', 'themes', 'configs', 'profile'];
for (const d of dirs) ensureDir(path.join(GP, d));
try {
PROTECTED_GAME_DIRS.concat(['mods', 'natives', 'servers', 'resourcepacks']).forEach(function (d) {
try { ensureDir(path.join(GP, d)); } catch (e) { }
});
versionList().forEach(function (ver) {
PROTECTED_GAME_DIRS.concat(['mods', 'natives', 'servers', 'resourcepacks']).forEach(function (d) {
try { ensureDir(path.join(ver.gamePath, d)); } catch (e) { }
});
});
} catch (e) { }
try { versionList().forEach(function (ver) { writeMinecraftOptions(ver.gamePath); }); } catch (e) { }
try { writeMinecraftOptions(GP); } catch (e) { }
cleanupStaleFiles(vv);
reportPct(4, 'Проверка всех файлов...');
const tasks = [];
for (const lib of vv.vanillaLibs) {
tasks.push({
rel: path.join('libraries', lib.split('/').pop()),
url: MOJANG_LIBS + lib,
jar: true
});
}
for (const lib of vv.fabricLibs) {
tasks.push({
rel: path.join('libraries', lib.split('/').pop()),
url: FABRIC_MAVEN + lib,
jar: true
});
}
tasks.push({ rel: path.join('assets', 'log4j2.xml'), url: vv.log4jUrl });
tasks.push({ rel: path.join('assets', 'indexes', vv.assetIndexId + '.json'), url: vv.assetIndexUrl });
tasks.push({ rel: path.join('libraries', 'client.jar'), url: vv.clientUrl, jar: true });
const nativesDir = path.join(GP, 'natives');
const nativesMarker = path.join(nativesDir, '.ok');
const assetsMarker = path.join(GP, 'assets', '.ok');
const modSrc = modSourceFor(vv);
const modInstalledPath = path.join(GP, vv.modInstalled || 'NebulaVisuals.jar');
// Если в игре лежит не тот файл, что на Dropbox — качаем именно с Dropbox,
// а не подсовываем старый бандл из установщика
const remoteOutdated = (() => {
try {
if (!REMOTE_MOD_META || !REMOTE_MOD_META.size) return false;
if (!isRealJar(modInstalledPath)) return true;
return fs.statSync(modInstalledPath).size !== REMOTE_MOD_META.size;
} catch (e) { return false; }
})();
const modsPlan = [
{
rel: path.join('mods', vv.modInstalled || 'NebulaVisuals.jar'),
local: modSrc,
url: MOD_URL,
useRemote: remoteOutdated
},
{ rel: path.join('mods', 'fabric-api.jar'), url: FAPI_URL },
{ rel: path.join('mods', VOICECHAT_FILE), local: LOCAL_VOICECHAT, url: VOICECHAT_URL }
];
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0432\u0441\u0435\u0445 \u0444\u0430\u0439\u043b\u043e\u0432...');
const toDownload = [];
for (const t of tasks) {
const full = path.join(GP, t.rel);
const ok = t.jar ? isRealJar(full) : isRealFile(full, 2);
if (!ok) toDownload.push(t);
}
for (const m of modsPlan) {
const full = path.join(GP, m.rel);
const needsUpdate = (m.rel === path.join('mods', vv.modInstalled || 'NebulaVisuals.jar')) && clientModOutdated(vv);
if (!isRealJar(full) || needsUpdate) toDownload.push(m);
}
const nativesFiles = ['lwjgl.dll', 'glfw.dll', 'jemalloc.dll'];
let nativesMissing = false;
for (const f of nativesFiles) {
if (!isRealFile(path.join(nativesDir, f), 1024)) { nativesMissing = true; break; }
}
if (!isRealFile(nativesMarker)) nativesMissing = true;
const assetsQueue = [];
let totalAssetObjects = 0;
let assetsIndex = null;
const assetsAlreadyDone = assetsComplete(GP, vv);
if (!assetsAlreadyDone) {
assetsIndex = readAssetIndex(GP, vv);
} else {
try { totalAssetObjects = parseInt(fs.readFileSync(assetsMarker, 'utf8').trim(), 10) || 0; } catch (e) { totalAssetObjects = 0; }
}
if (assetsIndex && assetsIndex.objects) {
const objects = assetsIndex.objects;
const seen = new Set();
for (const key of Object.keys(objects)) {
const hash = objects[key] && objects[key].hash;
if (!hash) continue;
const sub = hash.substring(0, 2);
const full = path.join(GP, 'assets', 'objects', sub, hash);
if (seen.has(full)) continue;
seen.add(full);
totalAssetObjects++;
if (!isRealFile(full, 1)) {
assetsQueue.push({ path: full, url: 'https://resources.download.minecraft.net/' + sub + '/' + hash });
}
}
}
const totalToDownload = toDownload.length + (nativesMissing ? 1 : 0) + assetsQueue.length;
const totalItemsAll = Math.max(1, totalToDownload + assetsQueue.length);
let itemsDone = 0;
const itemProgress = (idx) => (received, total) => {
if (total && total > 0) {
reportPct(12 + ((idx + received / total) / totalItemsAll) * 45, 'Скачивание файлов...');
}
};
reportPct(10, 'Проверка всех файлов...');
sendStatus(totalToDownload > 0
? ('\u041d\u0443\u0436\u043d\u043e \u0441\u043a\u0430\u0447\u0430\u0442\u044c \u0444\u0430\u0439\u043b\u043e\u0432: ' + totalToDownload + '...')
: '\u0412\u0441\u0435 \u0444\u0430\u0439\u043b\u044b \u043f\u0440\u043e\u0432\u0435\u0440\u0435\u043d\u044b \u2014 \u0432\u0441\u0451 \u0430\u043a\u0442\u0443\u0430\u043b\u044c\u043d\u043e');
let doneCount = 0;
let failCount = 0;
for (const t of toDownload) {
doneCount++;
itemsDone++;
reportPct(12 + (itemsDone / totalItemsAll) * 45, 'Скачивание файлов...');
const full = path.join(GP, t.rel);
const isMod = t.rel.indexOf('mods' + path.sep) === 0;
if (isMod) modsTouched++;
if (isMod) {
sendStatus('\u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 ' + path.basename(t.rel) + ' (' + doneCount + '/' + toDownload.length + ')...');
let copied = false;
const wantRemote = !!t.useRemote;
if (!wantRemote && t.local && isRealJar(t.local)) {
try {
ensureDir(path.dirname(full));
try {
fs.copyFileSync(t.local, full);
copied = isRealJar(full);
} catch (e) {
// файлы внутри app.asar нельзя копировать на уровне ОС — читаем вручную
try {
const data = fs.readFileSync(t.local);
fs.writeFileSync(full, data);
copied = isRealJar(full);
} catch (e2) { copied = false; }
}
} catch (e) { copied = false; }
}
if (!copied && t.url) {
try {
await downloadRetry(t.url, full, 3, itemProgress(itemsDone - 1));
copied = isRealJar(full);
if (!copied) { try { fs.unlinkSync(full); } catch (e) { } }
} catch (e) { }
}
if (!copied) failCount++;
} else {
sendStatus('\u0421\u043a\u0430\u0447\u0438\u0432\u0430\u043d\u0438\u0435 ' + path.basename(t.rel) + ' (' + doneCount + '/' + toDownload.length + ')...');
try {
await downloadRetry(t.url, full, 3, itemProgress(itemsDone - 1));
} catch (e) {
failCount++;
}
}
}
itemsDone = toDownload.length;
reportPct(57, 'Проверка всех файлов...');
if (failCount > 0) {
throw new Error('\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043a\u0430\u0447\u0430\u0442\u044c \u0447\u0430\u0441\u0442\u044c \u0444\u0430\u0439\u043b\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u0438 \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0441\u043d\u043e\u0432\u0430.');
}
const required = [
path.join(GP, 'libraries', 'client.jar'),
path.join(GP, 'libraries', 'fabric-loader-0.19.5.jar'),
path.join(GP, 'libraries', 'intermediary-' + vv.gameVersion + '.jar'),
path.join(GP, 'mods', vv.modInstalled || 'NebulaVisuals.jar'),
path.join(GP, 'mods', 'fabric-api.jar'),
path.join(GP, 'assets', 'indexes', vv.assetIndexId + '.json'),
path.join(GP, 'assets', 'log4j2.xml')
];
for (const p of required) {
if (!isRealFile(p, 2)) throw new Error('\u0424\u0430\u0439\u043b \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d: ' + path.basename(p));
}
reportPct(92, 'Извлечение системных библиотек...');
if (nativesMissing) {
sendStatus('\u0418\u0437\u0432\u043b\u0435\u0447\u0435\u043d\u0438\u0435 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0445 \u0431\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a...');
const psNatives = [
'Add-Type -AssemblyName System.IO.Compression.FileSystem',
"$dest = Join-Path (Get-Location) 'natives'",
'New-Item -ItemType Directory -Force -Path $dest | Out-Null',
'$n = 0',
"Get-ChildItem -Path 'libraries' -Filter '*-natives-windows.jar' | ForEach-Object {",
'  try {',
'    $zip = [System.IO.Compression.ZipFile]::OpenRead($_.FullName)',
'    foreach ($e in $zip.Entries) {',
"      if ($e.Name -like '*.dll') {",
'        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path $dest $e.Name), $true)',
'        $n++',
'      }',
'    }',
'    $zip.Dispose()',
'  } catch { }',
'}',
'if ($n -eq 0) { exit 1 }'
].join('\n');
await runHidden('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psNatives], GP);
fs.writeFileSync(nativesMarker, 'ok');
}
if (assetsQueue.length > 0) {
let completed = 0;
let failed = 0;
let lastTick = 0;
const total = assetsQueue.length;
sendStatus('\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0440\u0435\u0441\u0443\u0440\u0441\u043e\u0432 ' + total + '...');
await runPool(assetsQueue, 32, async (item) => {
try {
await downloadRetry(item.url, item.path, 2);
} catch (e) {
failed++;
}
completed++;
reportPct(57 + (assetsQueue.length ? (completed / assetsQueue.length) * 33 : 0), 'Загрузка ресурсов игры...');
const now = Date.now();
if (now - lastTick > 900 || completed === total) {
lastTick = now;
sendStatus('\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0440\u0435\u0441\u0443\u0440\u0441\u043e\u0432 ' + completed + '/' + total + '...');
}
});
if (failed > 0) {
throw new Error('\u0427\u0430\u0441\u0442\u044c \u0440\u0435\u0441\u0443\u0440\u0441\u043e\u0432 \u043d\u0435 \u0441\u043a\u0430\u0447\u0430\u043b\u0430\u0441\u044c (' + failed + '). \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u0438 \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0441\u043d\u043e\u0432\u0430.');
}
}
if (assetsAlreadyDone) {
} else if (assetsIndex && assetsIndex.objects && totalAssetObjects > 0) {
try { fs.writeFileSync(assetsMarker, String(totalAssetObjects)); } catch (e) { }
} else {
try { if (fs.existsSync(assetsMarker)) fs.unlinkSync(assetsMarker); } catch (e) { }
}
reportPct(97, 'Финальная проверка...');
if (!checkFilesDetailed(sendStatus, vv).ok) {
throw new Error('\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u0447\u0430\u0441\u0442\u044c \u0444\u0430\u0439\u043b\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \xab\u0417\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c\xbb \u0435\u0449\u0451 \u0440\u0430\u0437.');
}
reportPct(100, 'Все файлы актуальны');
return { modsTouched };
}


async function installAndLaunch(rawUser, rawRam, sendStatus, versionId) {
const username = rawUser;
const ram = rawRam;
const safeUser = (username || 'Player').replace(/[^a-zA-Z0-9_]/g, '') || 'Player';
const safeRam = parseInt(ram, 10) || 2048;
const v = getVersion(versionId);
const launchSlot = freeSlotForLaunch();
const GP = gamePathFor(launchSlot, v.id);
const vv = Object.assign({}, v, { gamePath: GP, launchSlot: launchSlot });
try {
const userDataPath = app.getPath('userData');
ensureDir(userDataPath);
ensureDir(GP);
try {
const seed = seedInstanceFiles(v.id, launchSlot);
if (seed.seeded) sendStatus('\u0417\u0430\u043f\u0443\u0441\u043a #' + launchSlot + ': \u0444\u0430\u0439\u043b\u044b \u0443\u0436\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u044b, \u0441\u043a\u0430\u0447\u0438\u0432\u0430\u043d\u0438\u0435 \u043d\u0435 \u043d\u0443\u0436\u043d\u043e');
} catch (e) { }
try {
fs.writeFileSync(path.join(userDataPath, 'launcher-config.json'), JSON.stringify({ username: safeUser, ram: safeRam, version: v.id }, null, 2));
} catch (e) { }
const h = crypto.createHash('md5').update('OfflinePlayer:' + safeUser).digest();
h[6] = (h[6] & 0x0f) | 0x30;
h[8] = (h[8] & 0x3f) | 0x80;
const hx = h.toString('hex');
const uuid = hx.slice(0, 8) + '-' + hx.slice(8, 12) + '-' + hx.slice(12, 16) + '-' + hx.slice(16, 20) + '-' + hx.slice(20);
sendStatus('\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044b\u0445 \u0444\u0430\u0439\u043b\u043e\u0432...');
const javaExe = await ensureJava(GP, sendStatus);
const check = checkFilesDetailed(sendStatus, vv);
if (check.ok) {
sendStatus('\u0412\u0441\u0435 \u0444\u0430\u0439\u043b\u044b \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u044b. \u0417\u0430\u043f\u0443\u0441\u043a...');
return startGame(javaExe, safeUser, safeRam, uuid, sendStatus, vv);
}
if (check.update) {
sendStatus('\u0412\u044b\u0448\u043b\u043e \u043d\u043e\u0432\u043e\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435. \u0417\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u0435 \u043a\u043b\u0438\u0435\u043d\u0442, \u0447\u0442\u043e\u0431\u044b \u0432\u0441\u0451 \u0441\u043a\u0430\u0447\u0430\u043b\u043e\u0441\u044c.');
await new Promise(r => setTimeout(r, 1500));
}
await ensureGameFiles(GP, vv, sendStatus);
await startGame(javaExe, safeUser, safeRam, uuid, sendStatus, vv);
} catch (err) {
throw err;
}
}
const MODRINTH_API = 'https://api.modrinth.com/v2';
const { net } = require('electron');
function netGetJson(url) {
return new Promise((resolve) => {
let done = false;
const finish = (v) => { if (done) return; done = true; resolve(v); };
try {
const ac = new AbortController();
const timer = setTimeout(() => { try { ac.abort(); } catch (e) { } }, 12000);
net.fetch(url, { headers: { 'User-Agent': 'NebulaVisuals/' + PKG_VERSION + ' (launcher)', 'Accept': 'application/json' }, signal: ac.signal })
.then((r) => {
clearTimeout(timer);
if (!r || r.status !== 200) { clearTimeout(timer); return finish({ ok: false, error: 'Modrinth: HTTP ' + (r ? r.status : '?') }); }
return r.json().then((j) => finish({ ok: true, json: j })).catch(() => finish({ ok: false, error: 'Modrinth: \u043d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442' }));
})
.catch((e) => { clearTimeout(timer); finish({ ok: false, error: '\u041d\u0435\u0442 \u0441\u0432\u044f\u0437\u0438 \u0441 Modrinth' }); });
} catch (e) {
finish({ ok: false, error: '\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u043f\u0440\u043e\u0441\u0430 \u043a Modrinth' });
}
});
}
function httpsGetJson(url) {
return new Promise((resolve) => {
let done = false;
const finish = (v) => { if (done) return; done = true; resolve(v); };
try {
const u = new URL(url);
const req = https.request({
hostname: u.hostname,
path: u.pathname + u.search,
method: 'GET',
agent: httpsAgent,
headers: { 'User-Agent': 'NebulaVisuals/' + PKG_VERSION + ' (launcher)', 'Accept': 'application/json' }
}, (res) => {
let body = '';
res.on('data', (c) => { body += c; });
res.on('end', () => {
if (res.statusCode !== 200) return finish({ ok: false, error: 'Modrinth: HTTP ' + res.statusCode });
try { finish({ ok: true, json: JSON.parse(body) }); }
catch (e) { finish({ ok: false, error: 'Modrinth: \u043d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442' }); }
});
});
req.setTimeout(15000, () => { try { req.destroy(); } catch (e) { } finish({ ok: false, error: 'Modrinth: \u0442\u0430\u0439\u043c\u0430\u0443\u0442' }); });
req.on('error', () => finish({ ok: false, error: '\u041d\u0435\u0442 \u0441\u0432\u044f\u0437\u0438 \u0441 Modrinth' }));
req.end();
} catch (e) {
finish({ ok: false, error: '\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u043f\u0440\u043e\u0441\u0430 \u043a Modrinth' });
}
});
}
async function modrinthGet(url) {
let r = await httpsGetJson(url);
if (r.ok) return r;
const n = await netGetJson(url);
if (n.ok) return n;
r = await httpsGetJson(url);
if (r.ok) return r;
return { ok: false, error: '\u041d\u0435\u0442 \u0441\u0432\u044f\u0437\u0438 \u0441 Modrinth \u2014 \u043f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u043e\u0435\u0434\u0438\u043d\u0435\u043d\u0438\u0435 \u0438\u043b\u0438 VPN \u0438 \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0441\u043d\u043e\u0432\u0430' };
}
ipcMain.handle('mods:search', async (event, payload) => {
const query = String((payload && payload.query) || '').trim();
const limit = Math.max(10, Math.min(Number((payload && payload.limit) || 100), 100));
const offset = Math.max(0, Number((payload && payload.offset) || 0));
const cat = String((payload && payload.cat) || '').trim();
const facetList = [['project_type:mod'], ['categories:fabric']];
if (cat) facetList.push(['categories:' + cat]);
const facets = encodeURIComponent(JSON.stringify(facetList));
const url = MODRINTH_API + '/search?query=' + encodeURIComponent(query) +
'&limit=' + limit + '&offset=' + offset + '&facets=' + facets + '&index=downloads';
const res = await modrinthGet(url);
if (!res.ok) return res;
const hits = (res.json && res.json.hits) || [];
return {
ok: true,
total: (res.json && res.json.total_hits) || hits.length,
mods: hits.map(function (h) {
return {
id: h.project_id,
title: h.title || '\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f',
description: (h.description || '').replace(/<[^>]*>/g, '').slice(0, 160),
icon: h.icon_url || '',
downloads: h.downloads || 0,
author: h.author || ''
};
})
};
});
ipcMain.handle('mods:project', async (event, payload) => {
const id = String((payload && payload.id) || '').trim();
if (!id) return { ok: false, error: '\u041d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d \u043c\u043e\u0434' };
const res = await modrinthGet(MODRINTH_API + '/project/' + encodeURIComponent(id));
if (!res.ok) return res;
const m = res.json || {};
return {
ok: true,
mod: {
id: m.id || id,
title: m.title || '',
description: (m.description || '').replace(/<[^>]*>/g, '').trim(),
icon: m.icon_url || '',
author: m.author || '',
downloads: m.downloads || 0,
follows: m.follows || 0,
categories: m.categories || [],
gallery: (m.gallery || []).map(function (g) { return { url: g.url, title: g.title || '' }; }),
sourceUrl: m.source_url || ''
}
};
});
ipcMain.handle('mods:download', async (event, payload) => {
const id = String((payload && payload.id) || '').trim();
const mc = String((payload && payload.mc) || '').trim();
if (!id || !mc) return { ok: false, error: '\u041d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d \u043c\u043e\u0434 \u0438\u043b\u0438 \u0441\u0431\u043e\u0440\u043a\u0430' };
const v = getVersion(mc);
if (!v) return { ok: false, error: '\u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f \u0441\u0431\u043e\u0440\u043a\u0430' };
const versionsRes = await modrinthGet(MODRINTH_API + '/project/' + encodeURIComponent(id) + '/version');
if (!versionsRes.ok) return versionsRes;
const list = Array.isArray(versionsRes.json) ? versionsRes.json : [];
const found = list.find(function (x) {
return x.loaders && x.loaders.indexOf('fabric') !== -1
&& x.game_versions && x.game_versions.indexOf(mc) !== -1
&& x.files && x.files.length;
});
if (!found) return { ok: false, error: '\u0414\u043b\u044f \u0441\u0431\u043e\u0440\u043a\u0438 ' + mc + ' \u043d\u0435\u0442 \u043f\u043e\u0434\u0445\u043e\u0434\u044f\u0449\u0435\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u043c\u043e\u0434\u0430' };
const file = found.files.find(function (f) { return f.primary; }) || found.files[0];
const modsDir = path.join(v.gamePath, 'mods');
ensureDir(modsDir);
const dest = path.join(modsDir, file.filename);
try {
await httpDownload(file.url, dest);
} catch (e) {
return { ok: false, error: '\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043a\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434: ' + (e && e.message ? e.message : e) };
}
if (!isRealJar(dest)) {
try { fs.unlinkSync(dest); } catch (e) { }
return { ok: false, error: '\u0421\u043a\u0430\u0447\u0430\u043d\u043d\u044b\u0439 \u0444\u0430\u0439\u043b \u043f\u043e\u0432\u0440\u0435\u0436\u0434\u0451\u043d' };
}
return {
ok: true,
file: file.filename,
path: dest,
version: found.version_number || '',
size: file.size || 0,
mc: mc
};
});
ipcMain.on('launch-game', async (event, username, ram, version) => {
if (launchInProgress) return;
launchInProgress = true;
const send = (msg) => {
try { event.sender.send('launch-status', msg); } catch (e) { }
};
const done = () => {
setTimeout(() => {
try { event.sender.send('launch-done'); } catch (e) { }
}, 400);
};
try {
await installAndLaunch(username, ram, send, version || '1.21.4');
done();
setTimeout(() => {
try { event.sender.send('launch-status', ''); } catch (e) { }
}, 15000);
} catch (err) {
send('\u041e\u0448\u0438\u0431\u043a\u0430: ' + (err && err.message ? err.message : err));
done();
} finally {
launchInProgress = false;
}
});
app.whenReady().then(async () => {
try { getOrCreateHwid(); } catch (e) { }
if (process.argv.indexOf('--selftest') !== -1) {
try {
await installAndLaunch('SelfTest', 2048, (m) => console.log('[STATUS] ' + m));
console.log('SELFTEST_OK');
} catch (e) {
console.log('SELFTEST_FAIL ' + (e && e.message ? e.message : e));
}
app.quit();
return;
}
createWindow();
app.on('activate', () => {
if (BrowserWindow.getAllWindows().length === 0) { createWindow(); }
});
});
app.on('window-all-closed', () => {
if (process.platform !== 'darwin') app.quit();
});