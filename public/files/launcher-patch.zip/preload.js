/* nvPROTECTED */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
closeWindow: () => ipcRenderer.send('window:close'),
minimizeWindow: () => ipcRenderer.send('window:minimize'),
launchGame: (username, ram) => ipcRenderer.send('launch-game', username, ram),
checkFiles: () => ipcRenderer.send('check-files')
});